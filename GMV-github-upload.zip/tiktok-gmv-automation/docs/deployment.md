# Deployment

Three parts (spec §8): **Web** (Vercel), **Worker** (dedicated host with Chrome + Edge),
**Supabase** (auth + durable state). Browser automation never runs on Vercel.

```
[User] → Vercel (Next.js)  → WORKER_BASE_URL → [Worker host: Chrome + Edge + Playwright]
                 │                                        │
                 └──────────── Supabase (Postgres + Storage + Auth) ────────┘
```

## 1. Worker host (the important one)

The Worker must run where **Google Chrome Stable** and **Microsoft Edge Stable** are really
installed, because US uses Chrome and UK uses Edge (spec §6). Manual TikTok login (spec §9)
needs a *visible* browser, so pick one:

| Option | Login | Job runs | Notes |
|---|---|---|---|
| **Windows PC / VM** (recommended) | native, headful | headful or headless | matches this project's dev setup; simplest for manual login/CAPTCHA |
| Linux host + desktop/VNC | via VNC once | headless (`GMV_HEADLESS=1`) | use `docker/worker.Dockerfile`; log in through VNC, then run headless |
| Managed Chromium-only cloud | ✕ | — | rejected: cannot provide a real Edge channel (spec §8) |

### Windows/VM (native)
```powershell
cd worker
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m playwright install chrome msedge
$env:GMV_HOST="0.0.0.0"; .\.venv\Scripts\python.exe -m gmv.worker_main
```
Then log in once per account (opens real browsers you control):
`POST /profiles/US_CHROME/login`, `POST /profiles/UK_EDGE/login`.

### Docker (Linux)
```bash
docker compose -f docker/docker-compose.yml up --build
# first login: attach a VNC/xvfb session, or pre-seed /data/profiles from a desktop host
```
Sessions + job files persist in the `gmv-data` volume (`/data`) across restarts (spec §17).

> Keep the Playwright pip version aligned with the base image tag in `worker.Dockerfile`
> (`v1.48.0-jammy` ↔ `playwright~=1.48`) so the installed channels match.

## 2. Web (Vercel)
- Root: `apps/web`. Framework preset: Next.js.
- Env: `WORKER_BASE_URL` = the Worker's reachable URL (put the Worker behind HTTPS/auth;
  do not expose it publicly unauthenticated). Optionally the `NEXT_PUBLIC_SUPABASE_*` vars.
- `npm run build` is verified locally (all routes compile).

## 3. Supabase
```bash
supabase db push          # applies supabase/migrations/0001_init.sql
```
- Create a **private** Storage bucket for Excel files; serve downloads via short-lived
  signed URLs (spec §14). RLS in the migration restricts every row to its owner.
- A scheduled function should delete files/rows past `expires_at` (default 7 days, §14).

## Security checklist (spec §9, §14)
- ✅ No TikTok credentials stored anywhere; login is manual.
- ✅ Session/cookie/profile files are gitignored and live only on the Worker host.
- ✅ File contents are never logged.
- ✅ Downloads use signed, short-lived URLs (Supabase) / auth-gated proxy (MVP).
- ⚠️ Put the Worker API behind authentication before exposing it beyond localhost.

## Known follow-ups
- Transitive `postcss` advisory via Next build tooling — resolved only by a Next major
  bump; revisit when upgrading to Next 15.
- Confirm live selectors + UK affiliate host (docs/decisions.md → UNVERIFIED).
