"""Job orchestration for the single-profile MVP workflow."""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field

from gmv.config import BrowserProfile, ProfileStatus, get_default_profile, get_profile
from gmv.excel_engine import WorkbookPlan, read_workbook, write_results
from gmv.models import ErrorCode, JobCancelledError, LookupResult, RowStatus

# A session must implement: async start()->ProfileStatus, async search_creator(str)->LookupResult,
# async close()->None.
SessionFactory = Callable[[BrowserProfile], object]
ProgressCallback = Callable[["JobProgress"], Awaitable[None] | None]


@dataclass
class JobProgress:
    total: int
    processed: int = 0
    success: int = 0
    range: int = 0
    failed: int = 0
    current: str | None = None


@dataclass
class JobResult:
    plan: WorkbookPlan
    results: dict[str, LookupResult] = field(default_factory=dict)
    output_path: str | None = None
    cancelled: bool = False

    @property
    def progress(self) -> JobProgress:
        p = JobProgress(total=len(self.results))
        for r in self.results.values():
            p.processed += 1
            if r.status is RowStatus.SUCCESS:
                p.success += 1
            elif r.status is RowStatus.RANGE:
                p.range += 1
            elif r.status is RowStatus.FAILED:
                p.failed += 1
        return p


def _assign_profiles(
    plan: WorkbookPlan, selected_profile_code: str | None
) -> dict[str, list[str]]:
    """Group every unique username under a single default profile."""
    groups: dict[str, dict[str, None]] = {}
    for sheet in plan.sheets:
        for row in sheet.rows:
            if not row.normalized_username:
                continue
            code = selected_profile_code or get_default_profile().profile_code
            groups.setdefault(code, {}).setdefault(row.normalized_username, None)
    return {code: list(names.keys()) for code, names in groups.items()}


async def _emit(cb: ProgressCallback | None, progress: JobProgress) -> None:
    if cb is None:
        return
    out = cb(progress)
    if asyncio.iscoroutine(out):
        await out


async def _run_group(
    profile: BrowserProfile,
    usernames: list[str],
    session_factory: SessionFactory,
    concurrency: int,
    results: dict[str, LookupResult],
    progress: JobProgress,
    cb: ProgressCallback | None,
    lock: asyncio.Lock,
    cancel_event=None,
) -> None:
    session = session_factory(profile)
    # Hand the session the cancel signal so its long waits can bail out early (§6).
    with contextlib.suppress(Exception):
        session.cancel_event = cancel_event
    status = await session.start()
    try:
        if status is not ProfileStatus.CONNECTED:
            code = (
                ErrorCode.SESSION_EXPIRED
                if status is ProfileStatus.EXPIRED
                else ErrorCode.LOGIN_REQUIRED
            )
            for name in usernames:
                async with lock:
                    results[name] = LookupResult(
                        normalized_username=name,
                        status=RowStatus.FAILED,
                        error_code=code,
                        account_label=profile.profile_code,
                    )
                    progress.failed += 1
                    progress.processed += 1
                await _emit(cb, progress)
            return

        async def worker(name: str) -> None:
            async with lock:
                progress.current = name
            res = await session.search_creator(name)
            async with lock:
                results[name] = res
                progress.processed += 1
                if res.status is RowStatus.SUCCESS:
                    progress.success += 1
                elif res.status is RowStatus.RANGE:
                    progress.range += 1
                else:
                    progress.failed += 1
            await _emit(cb, progress)

        for name in usernames:
            # Cooperative cancel checkpoint between creators (§6).
            if cancel_event is not None and cancel_event.is_set():
                raise JobCancelledError
            await worker(name)
    finally:
        await session.close()


async def run_job(
    input_path: str,
    output_path: str,
    *,
    session_factory: SessionFactory,
    selected_profile_code: str | None = None,
    concurrency: int = 1,
    sheets: list[str] | None = None,
    only_usernames: list[str] | None = None,
    prior_results: dict[str, LookupResult] | None = None,
    progress_cb: ProgressCallback | None = None,
    cancel_event=None,
) -> JobResult:
    """Run a full GMV job and write a format-preserving output workbook (spec §11).

    ``prior_results`` (used by retry, spec §15) seeds results that are NOT re-searched, so a
    retry of only-failed rows still preserves earlier successes in the output workbook.

    ``cancel_event`` (spec §6-§7): when set, the run stops cooperatively at the next checkpoint.
    Already-processed rows are kept; not-yet-processed rows are recorded as CANCELLED; a partial
    workbook is still written and ``JobResult.cancelled`` is True.
    """
    plan = read_workbook(input_path, sheets)
    groups = _assign_profiles(plan, selected_profile_code)

    if only_usernames is not None:
        retry = set(only_usernames)
        groups = {code: [n for n in names if n in retry] for code, names in groups.items()}
        groups = {code: names for code, names in groups.items() if names}

    total = sum(len(names) for names in groups.values())
    progress = JobProgress(total=total)
    results: dict[str, LookupResult] = dict(prior_results or {})
    lock = asyncio.Lock()

    cancelled = False
    try:
        for code, names in groups.items():
            await _run_group(
                get_profile(code), names, session_factory, 1, results, progress,
                progress_cb, lock, cancel_event,
            )
    except JobCancelledError:
        cancelled = True

    if cancelled:
        # Mark every not-yet-processed creator (including the one interrupted) as CANCELLED,
        # keeping all completed rows intact (spec §7).
        for names in groups.values():
            for name in names:
                if name not in results:
                    results[name] = LookupResult(
                        normalized_username=name,
                        status=RowStatus.CANCELLED,
                        account_label=selected_profile_code or get_default_profile().profile_code,
                    )

    out = write_results(input_path, plan, results, output_path)
    return JobResult(plan=plan, results=results, output_path=out, cancelled=cancelled)
