-- GMV automation schema (spec §7, §14).
-- Per-user privacy via RLS: a user can only see their own jobs/rows/files/profiles.
-- Files themselves live in Supabase Storage (private bucket); these tables hold metadata
-- and durable job state. TikTok credentials/cookies are NEVER stored here (spec §9, §14).

create extension if not exists "pgcrypto";

-- ---- browser_profiles (spec §7) --------------------------------------------------------
create table if not exists public.browser_profiles (
    id                 uuid primary key default gen_random_uuid(),
    user_id            uuid not null references auth.users (id) on delete cascade,
    profile_code       text not null,                 -- US_CHROME | UK_EDGE
    display_name       text not null,
    browser_channel    text not null,                 -- chrome | msedge
    market             text not null,                 -- US | UK
    shop_region        text not null,                 -- US | GB
    affiliate_url      text not null,
    session_provider   text not null default 'local_worker',
    remote_context_id  text,
    profile_storage_path text,
    status             text not null default 'disconnected',
    last_login_at      timestamptz,
    last_verified_at   timestamptz,
    last_used_at       timestamptz,
    last_error         text,
    created_at         timestamptz not null default now(),
    updated_at         timestamptz not null default now(),
    unique (user_id, profile_code)                    -- profile_code unique per user (spec §7)
);

-- ---- excel_jobs (spec §14) -------------------------------------------------------------
create table if not exists public.excel_jobs (
    id                          uuid primary key default gen_random_uuid(),
    user_id                     uuid not null references auth.users (id) on delete cascade,
    original_filename           text not null,
    selected_browser_profile_id uuid references public.browser_profiles (id),
    selected_profile_code       text,
    status                      text not null default 'uploaded',
    concurrency                 int  not null default 1,
    total_rows                  int  not null default 0,
    unique_creators             int  not null default 0,
    processed_rows              int  not null default 0,
    success_rows                int  not null default 0,
    range_rows                  int  not null default 0,
    failed_rows                 int  not null default 0,
    input_storage_path          text,
    output_storage_path         text,
    output_filename             text,
    expires_at                  timestamptz not null default (now() + interval '7 days'), -- §14
    started_at                  timestamptz,
    finished_at                 timestamptz,
    created_at                  timestamptz not null default now(),
    updated_at                  timestamptz not null default now()
);
create index if not exists excel_jobs_user_idx on public.excel_jobs (user_id, created_at desc);

-- ---- excel_job_rows (spec §14) ---------------------------------------------------------
create table if not exists public.excel_job_rows (
    id                     uuid primary key default gen_random_uuid(),
    job_id                 uuid not null references public.excel_jobs (id) on delete cascade,
    sheet_name             text not null,
    excel_row_number       int  not null,
    original_creator_value text not null,
    normalized_username    text,
    browser_profile_code   text,
    status                 text not null default 'PENDING',
    raw_gmv                text,
    gmv_value              numeric,
    gmv_type               text,
    items_sold             int,
    error_code             text,
    error_message          text,
    started_at             timestamptz,
    finished_at            timestamptz
);
create index if not exists excel_job_rows_job_idx on public.excel_job_rows (job_id, excel_row_number);

-- ---- excel_job_files (spec §14) --------------------------------------------------------
create table if not exists public.excel_job_files (
    id           uuid primary key default gen_random_uuid(),
    job_id       uuid not null references public.excel_jobs (id) on delete cascade,
    kind         text not null,                        -- input | output | error_csv
    storage_path text not null,
    byte_size    bigint,
    created_at   timestamptz not null default now()
);

-- ---- Row Level Security (spec §14: other users cannot access) ---------------------------
alter table public.browser_profiles enable row level security;
alter table public.excel_jobs      enable row level security;
alter table public.excel_job_rows  enable row level security;
alter table public.excel_job_files enable row level security;

create policy "own profiles" on public.browser_profiles
    for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "own jobs" on public.excel_jobs
    for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "own job rows" on public.excel_job_rows
    for all using (exists (
        select 1 from public.excel_jobs j where j.id = job_id and j.user_id = auth.uid()
    ));

create policy "own job files" on public.excel_job_files
    for all using (exists (
        select 1 from public.excel_jobs j where j.id = job_id and j.user_id = auth.uid()
    ));
