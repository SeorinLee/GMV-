"""GMV extraction providers with priority Network -> DOM (spec §11, D9).

Only responses the normal page already receives are inspected — no auth bypass, no
private-API guessing (spec §11). If network extraction yields nothing, the driver falls
back to DOM text. Both return a raw GMV string + optional items-sold; parsing/typing is
done by :func:`gmv.gmv_parser.parse_gmv` so range/open-ended rules apply uniformly.
"""

from __future__ import annotations

from typing import Any

# Candidate keys seen in creator/analytics JSON payloads. Best-effort; unknown shapes just
# fall through to the DOM extractor.
_GMV_KEYS = ("gmv", "gmv_amount", "gmvAmount", "total_gmv", "totalGmv", "gmv_str", "gmvStr")
_USERNAME_KEYS = ("unique_id", "uniqueId", "username", "handle", "creator_unique_id")
_ITEMS_KEYS = ("items_sold", "itemsSold", "sold_count", "soldCount", "sku_sold")


def _walk(obj: Any):
    """Yield every dict in a nested JSON structure."""
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            yield from _walk(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk(v)


def _first_key(d: dict, keys: tuple[str, ...]) -> Any | None:
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


def extract_from_json(payload: Any, expected_username_norm: str | None) -> tuple[str | None, int | None]:
    """Find a GMV string (and items) for the expected creator in a JSON payload.

    Only returns a value from a dict that also carries a matching username, so we never
    attribute another creator's GMV (spec §16). If no username field is present anywhere,
    returns the first GMV found (single-result search responses).
    """
    from gmv.creator import normalize_username

    fallback: tuple[str | None, int | None] = (None, None)
    saw_username_field = False

    for d in _walk(payload):
        gmv = _first_key(d, _GMV_KEYS)
        if gmv is None:
            continue
        gmv_str = str(gmv)
        items_raw = _first_key(d, _ITEMS_KEYS)
        items = int(items_raw) if isinstance(items_raw, (int, float)) else None

        uname = _first_key(d, _USERNAME_KEYS)
        if uname is not None:
            saw_username_field = True
            if expected_username_norm and normalize_username(str(uname)) == expected_username_norm:
                return gmv_str, items
        elif fallback == (None, None):
            fallback = (gmv_str, items)

    # If username fields existed but none matched, do not guess.
    return (None, None) if saw_username_field else fallback
