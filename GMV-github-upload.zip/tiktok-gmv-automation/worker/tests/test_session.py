"""Automation-layer tests for creator navigation + row-text GMV extraction.

The live Playwright DOM is UNVERIFIED (D10); these use a minimal fake page/locator that mimics
only the surface the session touches, so the navigation + extraction *logic* is covered without a
real browser. The extraction mirrors the proven approach: find the creator username via
get_by_text, walk up ancestor divs to the smallest container holding the username AND a "$", and
parse GMV + Items sold from that row's text.
"""

import asyncio
import re

import pytest

from gmv.automation import selectors
from gmv.automation.session import (
    AffiliateSessionExpiredError,
    SearchPageNotFoundError,
    TikTokAffiliateSession,
    find_all_matching,
)
from gmv.config import get_default_profile
from gmv.models import ErrorCode, GmvValueType, JobCancelledError, LookupResult, RowStatus


@pytest.fixture(autouse=True)
def _fast_timeouts(monkeypatch):
    """Keep the polling loops instant so the fake-DOM tests don't sit through real timeouts."""

    async def _no_sleep(_seconds):
        return None

    monkeypatch.setattr("gmv.automation.session.asyncio.sleep", _no_sleep)
    monkeypatch.setattr("gmv.automation.session.AUTOCOMPLETE_TIMEOUT_MS", 200)
    monkeypatch.setattr("gmv.automation.session.DETAIL_TIMEOUT_MS", 200)
    monkeypatch.setattr("gmv.automation.session.SEARCH_READY_TIMEOUT_MS", 200)
    monkeypatch.setattr("gmv.automation.session.SEARCH_TIMEOUT_MS", 200)


def _session():
    return TikTokAffiliateSession(get_default_profile(), headless=True)


def _run(coro):
    return asyncio.run(coro)


# ---- Fakes for navigation tests (ensure_find_creators_page) ----


class FakeElement:
    def __init__(self, username: str, text: str):
        self.username = username
        self.text = text

    async def inner_text(self):
        return self.text

    async def is_visible(self):
        return True

    def locator(self, selector: str):
        return FakeLocator([])


class FakeLocator:
    def __init__(self, elements: list):
        self._elements = elements

    @property
    def first(self):
        return self

    async def all(self):
        return list(self._elements)

    async def count(self):
        return len(self._elements)

    async def inner_text(self):
        return self._elements[0].text if self._elements else ""

    async def wait_for(self, state="visible", timeout=0):
        if not self._elements:
            raise TimeoutError("not visible")

    async def click(self):
        return None


class FakePage:
    def __init__(self, rows: list):
        self.rows = rows

    def locator(self, selector: str):
        if selector == selectors.RESULT_ROWS[0]:
            return FakeLocator(list(self.rows))
        return FakeLocator([])


class FlowPage:
    """Records navigations; SEARCH_INPUT visible only on the creator URL (spec §1, §3)."""

    def __init__(self, *, creator_has_search=True, redirect_to=None):
        self.urls: list = []
        self.url = "about:blank"
        self._creator_has_search = creator_has_search
        self._redirect_to = redirect_to
        self._p = get_default_profile()

    async def goto(self, url, wait_until=None):
        self.urls.append(url)
        self.url = self._redirect_to or url

    def on(self, *a, **k):
        return None

    def locator(self, selector):
        visible = (
            self.url == self._p.find_creators_url
            and selector in selectors.SEARCH_INPUT
            and self._creator_has_search
        )
        return FakeLocator([FakeElement("x", "x")] if visible else [])


def test_find_all_matching_checks_each_selector_individually():
    async def go():
        page = FakePage([FakeElement("x", "x")])
        found = await find_all_matching(page, selectors.RESULT_ROWS)
        assert len(found) == 1

    asyncio.run(go())


def test_ensure_navigates_straight_to_creator_not_target_invitation():
    async def go():
        session = _session()
        page = FlowPage()
        session._page = page
        search = await session.ensure_find_creators_page()
        assert search is not None
        assert page.urls == [session.profile.find_creators_url]
        assert session.profile.affiliate_entry_url not in page.urls

    asyncio.run(go())


def test_ensure_raises_session_expired_on_login_redirect():
    async def go():
        session = _session()
        session._page = FlowPage(redirect_to="https://seller-us.tiktok.com/account/register")
        with pytest.raises(AffiliateSessionExpiredError):
            await session.ensure_find_creators_page()

    asyncio.run(go())


def test_ensure_raises_search_page_not_found_when_creator_has_no_search():
    async def go():
        session = _session()
        session._page = FlowPage(creator_has_search=False)
        with pytest.raises(SearchPageNotFoundError):
            await session.ensure_find_creators_page()

    asyncio.run(go())


def test_search_creator_maps_session_expired_to_error_code():
    async def go():
        session = _session()
        session._page = FlowPage(redirect_to="https://seller-us.tiktok.com/account/register")
        result = await session.search_creator("someone")
        assert result.status is RowStatus.FAILED
        assert result.error_code is ErrorCode.SESSION_EXPIRED

    asyncio.run(go())


def test_search_creator_propagates_cancel():
    async def go():
        session = _session()
        session._page = FlowPage()
        event = asyncio.Event()
        event.set()
        session.cancel_event = event
        with pytest.raises(JobCancelledError):
            await session.search_creator("someone")

    asyncio.run(go())


# ---- Fake DOM for row-text extraction (get_by_text + ancestor walk) ----


class Node:
    """An element that is also a container + a page that supports get_by_text."""

    def __init__(self, text="", visible=True):
        self.text = text
        self._visible = visible
        self.clicked = False
        self._groups: list = []  # (set_of_selectors, [child Node])
        self._text_nodes: list = []

    def add(self, selectors_list, elements):
        self._groups.append((set(selectors_list), list(elements)))
        return self

    def add_text(self, node):
        self._text_nodes.append(node)
        return self

    def get_by_text(self, text, exact=True):
        matched = [n for n in self._text_nodes if (n.text == text if exact else text in n.text)]
        return _Loc(matched)

    @property
    def first(self):
        return self

    async def all(self):
        return [self]

    async def count(self):
        return 1

    async def inner_text(self, timeout=0):
        return self.text

    async def is_visible(self):
        return self._visible

    async def wait_for(self, state="visible", timeout=0):
        if not self._visible:
            raise TimeoutError("not visible")

    async def click(self):
        self.clicked = True

    def locator(self, selector):
        for sels, els in self._groups:
            if selector in sels:
                return _Loc(els)
        return _Loc([])


class _Loc:
    def __init__(self, elements):
        self._els = elements

    @property
    def first(self):
        return self._els[0] if self._els else Node(visible=False)

    async def all(self):
        return list(self._els)

    async def count(self):
        return len(self._els)


class _AncLoc:
    def __init__(self, text):
        self._t = text

    async def inner_text(self, timeout=0):
        if self._t is None:
            raise RuntimeError("no such ancestor")
        return self._t


class TextNode(Node):
    """A username text element whose ancestor::div[N] resolves to a preset text."""

    def __init__(self, text, ancestors):
        super().__init__(text=text)
        self._ancestors = ancestors  # {level: text}

    def locator(self, selector):
        m = re.search(r"ancestor::div\[(\d+)\]", selector)
        if m:
            return _AncLoc(self._ancestors.get(int(m.group(1))))
        return super().locator(selector)


class _BadNode(Node):
    async def click(self):
        raise RuntimeError("suggestion not clickable")


ROW_FULL = "\n".join([
    "yourboybigmike",
    "M I K E",
    "PPS: 4.7/5.0",
    "Beauty & Personal Care, +2",
    "10K, Female 65%, 35-44",
    "$150.1K",
    "4.8K",
])


def make_result_page(username, ancestors, *, detail_gmv=None):
    page = Node()
    page.add_text(TextNode(username, ancestors))
    if detail_gmv is not None:
        panel = Node("detail", visible=True)
        panel.add([selectors.GMV_LABELS[1]], [Node("GMV")])
        panel.add([selectors.GMV_VALUES[0]], [Node(detail_gmv)])
        page.add([selectors.DETAIL_PANEL[0]], [panel])
    return page


def make_suggestion_page(handle, *, click_bad=False):
    page = Node()
    node = _BadNode(text=handle) if click_bad else Node(text=handle)
    node.add([selectors.AUTOCOMPLETE_USERNAME[0]], [Node(handle)])
    page.add([selectors.render_autocomplete_suggestions("x")[0]], [node])
    return page


def _extract(session, username="yourboybigmike"):
    return session._identify_and_extract(username, LookupResult(normalized_username=username))


def test_row_text_gmv_150k_conversion():
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: ROW_FULL})
    r = _run(_extract(session))
    assert r.status is RowStatus.SUCCESS
    assert r.gmv.value == 150100
    assert r.source == "row_text"


def test_row_text_items_sold_4800_conversion():
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: ROW_FULL})
    r = _run(_extract(session))
    assert r.items_sold == 4800


def test_confirmed_screenshot_values_expand_to_numbers():
    row = "\n".join(["yourboybigmike", "M I K E", "PPS: 4.7/5.0", "$148.4K", "4.7K"])
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.status is RowStatus.SUCCESS
    assert r.gmv.value == 148400
    assert r.items_sold == 4700


def test_flattened_table_row_extracts_only_gmv_and_first_count_after_it():
    row = "yourboybigmike M I K E PPS: 4.7/5.0 10.1K Female 65% 35-44 $148.4K 4.7K 22.3K"
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.gmv.value == 148400
    assert r.items_sold == 4700


def test_items_sold_range_uses_maximum_value():
    row = "\n".join(["yourboybigmike", "$148.4K", "0-100"])
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.gmv.value == 148400
    assert r.items_sold_raw == "0-100"
    assert r.items_sold == 100


def test_items_sold_abbreviated_range_uses_expanded_maximum():
    row = "\n".join(["yourboybigmike", "$2M", "0-1.2K"])
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.items_sold == 1200


def test_items_found_within_1_to_3_lines_after_gmv():
    row = "\n".join(["yourboybigmike", "$150.1K", "not a number", "4.8K"])  # items 2 lines later
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.items_sold == 4800


def test_gmv_found_without_items_is_success():
    row = "\n".join(["yourboybigmike", "M I K E", "$150.1K"])  # no items line
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.status is RowStatus.SUCCESS
    assert r.items_sold is None


def test_range_gmv_records_upper_bound():
    row = "\n".join(["yourboybigmike", "$0-$5K"])
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: row})
    r = _run(_extract(session))
    assert r.status is RowStatus.RANGE
    assert r.gmv.value == 5000
    assert r.gmv.value_type is GmvValueType.RANGE_MAX  # "range_upper"


def test_ancestor_walk_picks_smallest_row_with_username_and_dollar():
    # Levels 2 and 3 hold the username but no $; level 4 is the row with the price.
    ancestors = {
        2: "yourboybigmike",
        3: "yourboybigmike\nM I K E",
        4: ROW_FULL,
        5: "wrapper " + ROW_FULL,
    }
    session = _session()
    session._page = make_result_page("yourboybigmike", ancestors)
    r = _run(_extract(session))
    assert r.status is RowStatus.SUCCESS
    assert r.gmv.value == 150100


def test_row_text_success_does_not_wait_for_detail_drawer():
    # No detail panel exists; if the code waited for one it would fail. Success => row_text used.
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: ROW_FULL})
    r = _run(_extract(session))
    assert r.status is RowStatus.SUCCESS
    assert r.source == "row_text"


def test_row_text_terminal_log_has_key_fields(capsys):
    session = _session()
    session._page = make_result_page("yourboybigmike", {2: "yourboybigmike", 3: ROW_FULL})
    _run(_extract(session))
    out = capsys.readouterr().out
    assert "[gmv-row] gmv_raw=$150.1K" in out
    assert "gmv_value=150100" in out
    assert "items_sold_value=4800" in out
    assert "extraction=success source=row_text" in out


def test_username_not_on_screen_is_creator_not_found():
    session = _session()
    session._page = Node()  # no text nodes
    r = _run(_extract(session))
    assert r.error_code is ErrorCode.CREATOR_NOT_FOUND


def test_username_found_but_no_row_is_result_row_not_found():
    session = _session()
    session._page = make_result_page("yourboybigmike", {})  # username element but no ancestors
    r = _run(_extract(session))
    assert r.error_code is ErrorCode.RESULT_ROW_NOT_FOUND


def test_row_without_dollar_and_no_detail_is_gmv_not_found():
    session = _session()
    session._page = make_result_page(
        "yourboybigmike", {2: "yourboybigmike", 3: "yourboybigmike\nM I K E"}
    )
    r = _run(_extract(session))
    assert r.error_code is ErrorCode.GMV_NOT_FOUND


def test_row_without_dollar_falls_back_to_detail_drawer():
    session = _session()
    session._page = make_result_page(
        "yourboybigmike", {2: "yourboybigmike", 3: "yourboybigmike\nM I K E"}, detail_gmv="$5K"
    )
    r = _run(_extract(session))
    assert r.status is RowStatus.SUCCESS
    assert r.source == "detail_panel"


def test_autocomplete_click_failure_maps_to_autocomplete_click_failed():
    session = _session()
    session._page = make_suggestion_page("@yourboybigmike", click_bad=True)
    r = _run(_extract(session))
    assert r.error_code is ErrorCode.AUTOCOMPLETE_CLICK_FAILED


def test_autocomplete_similar_handle_is_not_matched():
    # Dropdown shows @arlynvibes2 while we search arlynvibes -> mismatch (no exact suggestion).
    session = _session()
    session._page = make_suggestion_page("@arlynvibes2")
    r = _run(_extract(session, "arlynvibes"))
    assert r.error_code is ErrorCode.AUTOCOMPLETE_MISMATCH


def test_cancel_during_autocomplete_wait_raises():
    session = _session()
    page = Node()
    page.add([selectors.AUTOCOMPLETE_PANEL[0]], [Node("Creators")])
    session._page = page
    event = asyncio.Event()
    event.set()
    session.cancel_event = event
    with pytest.raises(JobCancelledError):
        _run(_extract(session))
