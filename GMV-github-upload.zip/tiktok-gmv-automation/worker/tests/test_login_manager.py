"""Login/verify URL-separation tests (Seller Center login vs Affiliate Center lookup).

The real Playwright DOM is UNVERIFIED (D10); a minimal fake ``playwright`` module is injected
so the *navigation targets* and the conservative login detection can be asserted without a
real browser. The fake page has nothing visible, so it stands in for a blank/loading screen —
which must never be reported as ``connected``.
"""

import asyncio
import sys
import types

import pytest

from gmv import login_manager
from gmv.automation.session import TikTokAffiliateSession
from gmv.config import ProfileStatus, get_default_profile


class _FakeLoc:
    def __init__(self, visible: bool = False, text: str = ""):
        self._visible = visible
        self._text = text

    @property
    def first(self):
        return self

    async def wait_for(self, state: str = "visible", timeout: int = 0):
        if not self._visible:
            raise TimeoutError("not visible")

    async def inner_text(self, timeout: int = 0):
        return self._text

    async def all(self):
        return [self] if self._visible else []

    async def count(self):
        return 1 if self._visible else 0


class _FakePage:
    """A blank page: no element is visible, so no login can be positively confirmed."""

    def __init__(self, urls: list, url: str = "about:blank"):
        self._urls = urls
        self.url = url

    async def goto(self, url: str, wait_until: str | None = None):
        self._urls.append(url)
        self.url = url

    def on(self, *args, **kwargs):
        return None

    def locator(self, selector: str):
        return _FakeLoc(visible=False)


class _FakeContext:
    def __init__(self, urls: list):
        self.pages: list = []
        self._urls = urls

    async def new_page(self):
        page = _FakePage(self._urls)
        self.pages.append(page)
        return page

    async def close(self):
        return None


class _FakeChromium:
    def __init__(self, urls: list):
        self._urls = urls

    async def launch_persistent_context(self, **kwargs):
        return _FakeContext(self._urls)


class _FakePW:
    def __init__(self, urls: list):
        self.chromium = _FakeChromium(urls)

    async def stop(self):
        return None


class _FakeStarter:
    def __init__(self, urls: list):
        self._urls = urls

    async def start(self):
        return _FakePW(self._urls)


@pytest.fixture
def fake_pw(monkeypatch, tmp_path):
    """Inject a fake playwright module and isolate status files under tmp."""
    monkeypatch.setenv("GMV_STORAGE_ROOT", str(tmp_path / "jobs"))
    urls: list = []

    def factory():
        return _FakeStarter(urls)

    mod = types.ModuleType("playwright")
    sub = types.ModuleType("playwright.async_api")
    sub.async_playwright = factory
    mod.async_api = sub
    monkeypatch.setitem(sys.modules, "playwright", mod)
    monkeypatch.setitem(sys.modules, "playwright.async_api", sub)

    async def _no_sleep(_seconds):
        return None

    monkeypatch.setattr(asyncio, "sleep", _no_sleep)
    return urls


def test_open_login_opens_login_url_not_affiliate(fake_pw, monkeypatch):
    monkeypatch.setattr(login_manager, "LOGIN_POLL_SECONDS", 1)
    profile = get_default_profile()
    result = asyncio.run(login_manager.open_login("DEFAULT"))

    assert profile.login_url in fake_pw
    assert profile.affiliate_url not in fake_pw
    # A blank Seller Center page must never be reported as connected.
    assert result["status"] != ProfileStatus.CONNECTED.value
    assert result["status"] == ProfileStatus.LOGIN_REQUIRED.value


def _install_fake_pw(monkeypatch, tmp_path, page_factory) -> list:
    """Install a fake playwright whose new page is built by ``page_factory(urls)``."""
    monkeypatch.setenv("GMV_STORAGE_ROOT", str(tmp_path / "jobs"))
    urls: list = []

    class _Ctx(_FakeContext):
        async def new_page(self):
            page = page_factory(self._urls)
            self.pages.append(page)
            return page

    class _Chromium(_FakeChromium):
        async def launch_persistent_context(self, **kwargs):
            return _Ctx(self._urls)

    class _PW(_FakePW):
        def __init__(self, u):
            self.chromium = _Chromium(u)

    class _Starter(_FakeStarter):
        async def start(self):
            return _PW(self._urls)

    mod = types.ModuleType("playwright")
    sub = types.ModuleType("playwright.async_api")
    sub.async_playwright = lambda: _Starter(urls)
    mod.async_api = sub
    monkeypatch.setitem(sys.modules, "playwright", mod)
    monkeypatch.setitem(sys.modules, "playwright.async_api", sub)
    return urls


class _RedirectToRegisterPage(_FakePage):
    """A logged-out session: any goto bounces to the Seller login/register page."""

    async def goto(self, url, wait_until=None):
        self._urls.append(url)
        self.url = "https://seller-us.tiktok.com/account/register"


def test_verify_uses_login_success_url_and_does_not_falsely_connect(monkeypatch, tmp_path):
    # verify checks the login-success page; a logged-out redirect must NOT be connected.
    urls = _install_fake_pw(monkeypatch, tmp_path, _RedirectToRegisterPage)
    profile = get_default_profile()
    result = asyncio.run(login_manager.verify("DEFAULT"))

    assert profile.login_success_url in urls
    assert result["status"] != ProfileStatus.CONNECTED.value
    assert result["status"] == ProfileStatus.EXPIRED.value


def test_gmv_session_opens_creator_url_directly(fake_pw):
    # The job goes straight to the creator page — never target-invitation or a login page (§1,§3).
    profile = get_default_profile()
    session = TikTokAffiliateSession(profile, headless=True)
    asyncio.run(session.start())

    assert profile.find_creators_url in fake_pw
    assert profile.affiliate_entry_url not in fake_pw
    assert profile.login_url not in fake_pw
    assert profile.login_success_url not in fake_pw


def test_account_register_url_is_not_treated_as_logged_out():
    # /account/register is the normal Seller Center login entry, not an expired session (§4,§5).
    from gmv.automation import selectors

    assert selectors.is_logged_out_url("https://seller-us.tiktok.com/account/register") is False


def test_detect_seller_login_on_register_page_is_login_required_not_error(fake_pw):
    # A blank/login page at /account/register must yield login_required, never connected/error.
    page = _FakePage([], url="https://seller-us.tiktok.com/account/register")
    status = asyncio.run(login_manager.detect_seller_login(page))
    assert status is ProfileStatus.LOGIN_REQUIRED


@pytest.mark.parametrize(
    ("url", "expected"),
    [
        ("https://seller-us.tiktok.com/affiliate/landing?is_new_connect=0&shop_region=US", True),
        ("https://seller-us.tiktok.com/affiliate/landing", True),
        ("https://seller-us.tiktok.com/affiliate/landing?foo=bar&x=1", True),  # query may differ
        ("https://seller-uk.tiktok.com/affiliate/landing?shop_region=GB", True),
        ("https://seller-us.tiktok.com/account/register", False),
        ("https://accounts.tiktok.com/login", False),
        ("about:blank", False),
        ("", False),
    ],
)
def test_is_seller_login_success(url, expected):
    assert login_manager.is_seller_login_success(url) is expected


class _LandingPage(_FakePage):
    """After any goto, the session keeps us on the login-success landing page."""

    async def goto(self, url, wait_until=None):
        self._urls.append(url)
        self.url = get_default_profile().login_success_url


def test_verify_connected_when_landing_and_no_login_form(monkeypatch, tmp_path):
    # verify() must return connected when the success page persists and no login form shows.
    _install_fake_pw(monkeypatch, tmp_path, _LandingPage)
    result = asyncio.run(login_manager.verify("DEFAULT"))
    assert result["status"] == ProfileStatus.CONNECTED.value
