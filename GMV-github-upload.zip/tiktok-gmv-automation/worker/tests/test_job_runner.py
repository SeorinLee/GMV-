"""Job runner tests for the selected browser/market profile flow."""

import asyncio

from openpyxl import Workbook, load_workbook

from gmv.config import ProfileStatus
from gmv.gmv_parser import parse_gmv
from gmv.job_runner import run_job
from gmv.models import ErrorCode, GmvValueType, LookupResult, RowStatus


class FakeSession:
    instances: list["FakeSession"] = []

    def __init__(self, profile, gmv_map, status=ProfileStatus.CONNECTED):
        self.profile = profile
        self.gmv_map = gmv_map
        self.status = status
        self.searched: list[str] = []
        FakeSession.instances.append(self)

    async def start(self):
        return self.status

    async def close(self):
        return None

    async def search_creator(self, name):
        self.searched.append(name)
        raw = self.gmv_map.get(name)
        if raw is None:
            return LookupResult(
                normalized_username=name,
                status=RowStatus.FAILED,
                error_code=ErrorCode.CREATOR_NOT_FOUND,
                account_label=self.profile.profile_code,
            )
        parsed = parse_gmv(raw)
        status = (
            RowStatus.RANGE
            if parsed.value_type in (GmvValueType.RANGE_MAX, GmvValueType.OPEN_ENDED_ESTIMATE)
            else RowStatus.SUCCESS
        )
        return LookupResult(
            normalized_username=name, gmv=parsed, status=status, account_label=self.profile.profile_code
        )


def _factory(gmv_map, status=ProfileStatus.CONNECTED):
    def make(profile):
        return FakeSession(profile, gmv_map, status)
    return make


def _wb_single(path):
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Creator Name"
    ws["A2"] = "@alpha"
    ws["A3"] = "beta"
    ws["A4"] = "alpha"
    wb.save(path)


def _wb_mixed(path):
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Creator Name"
    ws["B1"] = "Market"
    ws["A2"], ws["B2"] = "alpha", "US"
    ws["A3"], ws["B3"] = "beta", "UK"
    ws["A4"], ws["B4"] = "gamma", "미국"
    wb.save(path)


def setup_function():
    FakeSession.instances.clear()


def test_dedupe_searches_once(tmp_path):
    src = tmp_path / "s.xlsx"
    _wb_single(src)
    res = asyncio.run(
        run_job(
            str(src),
            str(tmp_path / "out.xlsx"),
            session_factory=_factory({"alpha": "$5K", "beta": "$1K-$5K"}),
            selected_profile_code="US_CHROME",
        )
    )
    assert len(FakeSession.instances) == 1
    assert sorted(FakeSession.instances[0].searched) == ["alpha", "beta"]
    ws = load_workbook(res.output_path).active
    assert ws["B2"].value == 5000
    assert ws["B4"].value == 5000


def test_single_profile_ignores_row_accounts(tmp_path):
    src = tmp_path / "m.xlsx"
    _wb_mixed(src)
    res = asyncio.run(
        run_job(
            str(src),
            str(tmp_path / "out.xlsx"),
            session_factory=_factory({"alpha": "$5K", "beta": "$9K", "gamma": "$2M"}),
        )
    )
    assert len(FakeSession.instances) == 1
    assert FakeSession.instances[0].profile.profile_code == "US_CHROME"
    assert res.progress.success == 3


def test_retry_only_requested(tmp_path):
    src = tmp_path / "r.xlsx"
    _wb_single(src)
    asyncio.run(
        run_job(
            str(src),
            str(tmp_path / "out.xlsx"),
            session_factory=_factory({"alpha": "$5K", "beta": "$1K"}),
            selected_profile_code="US_CHROME",
            only_usernames=["beta"],
        )
    )
    assert FakeSession.instances[0].searched == ["beta"]


def test_login_required_fails_all(tmp_path):
    src = tmp_path / "l.xlsx"
    _wb_single(src)
    res = asyncio.run(
        run_job(
            str(src),
            str(tmp_path / "out.xlsx"),
            session_factory=_factory({}, status=ProfileStatus.LOGIN_REQUIRED),
            selected_profile_code="US_CHROME",
        )
    )
    assert res.progress.failed == 2
    assert all(r.error_code is ErrorCode.LOGIN_REQUIRED for r in res.results.values())


def test_progress_callback_invoked(tmp_path):
    src = tmp_path / "p.xlsx"
    _wb_single(src)
    seen = []

    async def cb(p):
        seen.append(p.processed)

    asyncio.run(
        run_job(
            str(src),
            str(tmp_path / "out.xlsx"),
            session_factory=_factory({"alpha": "$5K", "beta": "$1K"}),
            selected_profile_code="US_CHROME",
            progress_cb=cb,
        )
    )
    assert seen
    assert max(seen) == 2
