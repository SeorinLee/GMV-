import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "TikTok GMV 자동 조회",
  description: "엑셀 업로드 → 크리에이터 GMV 자동 조회 → 완료 파일 다운로드",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>
        <header className="topbar">
          <Link href="/" className="brand">GMV 자동 조회</Link>
          <nav>
            <Link href="/">새 작업</Link>
            <Link href="/settings">TikTok 로그인</Link>
          </nav>
        </header>
        <main className="container">{children}</main>
      </body>
    </html>
  );
}
