"""Worker HTTP API (spec §1, §9, §10, §12, §13, §15 + cancel §5-§8).

FastAPI app the web front-end calls. Browser automation runs here (never on Vercel, spec §8).
The session factory is injected via app state so tests can supply a fake (no real browser).

A single browser profile is shared by login, verify, reset, GMV jobs and retries, so all of
them are serialized through one atomic *busy* reservation (spec §12): the flag is set
synchronously before any browser work is spawned, so two requests can never both pass the gate.
Whoever holds it releases it in a ``finally``. A running job may be stopped cooperatively via a
per-job ``asyncio.Event`` (spec §6). Interrupted jobs are recovered to ``failed`` on startup so
nothing is stuck in ``running`` after a restart (spec §12.7).
"""

from __future__ import annotations

import asyncio
import os

from fastapi import FastAPI, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse

from gmv.config import get_default_profile, get_profile, list_profiles
from gmv.service import UploadValidationError, process_job, validate_upload
from gmv.store import JobRecord, JobStatus, JobStore

_SANITIZE_KEYS = {
    "browser_channel",
    "market",
    "shop_region",
    "profile_storage_path",
    "affiliate_url",
    "affiliate_entry_url",
    "login_url",
    "login_success_url",
    "find_creators_url",
}

_INTERRUPTED_STATUSES = {
    JobStatus.VALIDATING,
    JobStatus.QUEUED,
    JobStatus.RUNNING,
    JobStatus.CANCEL_REQUESTED,
    JobStatus.MERGING,
}

_FINISHED_STATUSES = {
    JobStatus.COMPLETED,
    JobStatus.COMPLETED_WITH_ERRORS,
    JobStatus.FAILED,
    JobStatus.CANCELLED,
    JobStatus.NEEDS_LOGIN,
}


def _sanitize_profile_payload(payload: dict) -> dict:
    """Drop operator-only fields (browser/market/region/URLs/paths) from the client view (§10)."""
    return {k: v for k, v in payload.items() if k not in _SANITIZE_KEYS}


def _busy_conflict() -> JSONResponse:
    return JSONResponse(
        status_code=409,
        content={
            "detail": "현재 다른 TikTok 작업이 실행 중입니다. 완료 후 다시 시도하세요.",
            "code": "BROWSER_BUSY",
        },
    )


def real_session_factory(profile):
    from gmv.automation.session import TikTokAffiliateSession

    headless = os.environ.get("GMV_HEADLESS", "0") == "1"
    return TikTokAffiliateSession(profile, headless=headless)


def _recover_interrupted_jobs(store: JobStore) -> None:
    """Mark jobs left mid-flight by a crash/restart as failed (spec §12.7)."""
    for record in store.list():
        if record.status in _INTERRUPTED_STATUSES:
            record.status = JobStatus.FAILED
            record.current = None
            store.save(record)


def create_app(store: JobStore | None = None, session_factory=real_session_factory) -> FastAPI:
    app = FastAPI(title="GMV Worker", version="0.1.0")
    app.state.store = store or JobStore(os.environ.get("GMV_STORAGE_ROOT", "storage/jobs"))
    app.state.session_factory = session_factory
    app.state.tasks = set()  # strong refs so background tasks are not GC'd mid-run
    # Atomic single-flight gate over the shared browser profile (spec §12). Bool read+write
    # never suspends, so check-then-set is race-free on the single event loop.
    app.state.browser_busy = False
    # Per-job cooperative cancel signals (spec §6).
    app.state.job_cancel_events = {}
    _recover_interrupted_jobs(app.state.store)

    def _reserve() -> bool:
        if app.state.browser_busy:
            return False
        app.state.browser_busy = True
        return True

    def _release() -> None:
        app.state.browser_busy = False

    def _spawn_exclusive(coro) -> None:
        async def runner():
            try:
                await coro
            finally:
                _release()

        _spawn(app, runner())

    @app.get("/health")
    async def health():
        return {"ok": True}

    # ---- Profile status (single default profile, spec §10) ----

    @app.get("/profiles")
    async def profiles():
        from gmv.login_manager import read_status

        return [read_status(p.profile_code) for p in list_profiles()]

    @app.get("/profile")
    async def profile():
        from gmv.login_manager import read_status

        return _sanitize_profile_payload(read_status(get_default_profile().profile_code))

    @app.get("/profiles/{code}")
    async def profile_status(code: str):
        from gmv.login_manager import read_status

        try:
            return read_status(code)
        except KeyError as exc:
            raise HTTPException(404, "unknown profile") from exc

    # ---- Login / verify / reset (all share the browser, all gated, spec §12) ----

    def _do_login(code: str):
        from gmv.login_manager import open_login

        try:
            profile = get_profile(code)
        except KeyError as exc:
            raise HTTPException(404, "unknown profile") from exc
        if not _reserve():
            return _busy_conflict()
        _spawn_exclusive(open_login(profile.profile_code))
        return {"profile_code": profile.profile_code, "status": "connecting"}

    def _do_verify(code: str):
        from gmv.login_manager import verify

        try:
            profile = get_profile(code)
        except KeyError as exc:
            raise HTTPException(404, "unknown profile") from exc
        if not _reserve():
            return _busy_conflict()
        _spawn_exclusive(verify(profile.profile_code))
        return {"profile_code": profile.profile_code, "status": "verifying"}

    def _do_reset(code: str):
        from gmv.login_manager import reset

        try:
            profile = get_profile(code)
        except KeyError as exc:
            raise HTTPException(404, "unknown profile") from exc
        if not _reserve():
            return _busy_conflict()
        try:
            return reset(profile.profile_code)
        finally:
            _release()

    @app.post("/profiles/{code}/login")
    async def profile_login(code: str):
        return _do_login(code)

    @app.post("/profiles/{code}/verify")
    async def profile_verify(code: str):
        return _do_verify(code)

    @app.post("/profiles/{code}/reset")
    async def profile_reset(code: str):
        return _do_reset(code)

    @app.post("/profile/login")
    async def profile_login_alias():
        return _do_login(get_default_profile().profile_code)

    @app.post("/profile/verify")
    async def profile_verify_alias():
        return _do_verify(get_default_profile().profile_code)

    @app.post("/profile/reset")
    async def profile_reset_alias():
        return _do_reset(get_default_profile().profile_code)

    # ---- Jobs ----

    @app.post("/jobs")
    async def create_job(
        file: UploadFile,
        profile_code: str | None = Form(None),
        concurrency: int | None = Form(None),  # accepted for legacy clients, ignored (spec §4)
    ):
        store: JobStore = app.state.store

        if file.filename is None or not file.filename.lower().endswith(".xlsx"):
            return JSONResponse(
                status_code=400,
                content={
                    "detail": ".xlsx 형식의 Excel 파일만 업로드할 수 있습니다.",
                    "code": "INVALID_FILE_TYPE",
                },
            )

        try:
            profile = get_profile(profile_code or get_default_profile().profile_code)
        except KeyError:
            return JSONResponse(
                status_code=400,
                content={"detail": "지원하지 않는 브라우저/마켓입니다.", "code": "INVALID_PROFILE"},
            )

        if not _reserve():
            return _busy_conflict()
        record = JobRecord(
            original_filename=file.filename or "upload.xlsx",
            selected_profile_code=profile.profile_code,
            concurrency=1,
            status=JobStatus.VALIDATING,
        )
        store.save(record)
        store.input_path(record.id).write_bytes(await file.read())

        try:
            total, unique = validate_upload(store, record.id)
        except UploadValidationError as exc:
            store.delete(record.id)  # clean up the rejected upload (spec §13)
            _release()
            return JSONResponse(status_code=400, content={"detail": exc.detail, "code": exc.code})
        except Exception:  # noqa: BLE001
            store.delete(record.id)
            _release()
            return JSONResponse(
                status_code=400,
                content={
                    "detail": "Excel 파일을 열 수 없습니다. 파일이 손상되었거나 지원되지 않는 형식입니다.",
                    "code": "INVALID_EXCEL",
                },
            )

        record.total_rows, record.unique_creators = total, unique
        record.status = JobStatus.QUEUED
        store.save(record)

        cancel_event = asyncio.Event()
        app.state.job_cancel_events[record.id] = cancel_event
        _spawn_exclusive(_run(app, record.id, cancel_event))
        return {"job_id": record.id, "total_rows": total, "unique_creators": unique}

    @app.get("/jobs")
    async def list_jobs():
        return [r.model_dump() for r in app.state.store.list()]

    @app.get("/jobs/{job_id}")
    async def get_job(job_id: str):
        record = app.state.store.get(job_id)
        if record is None:
            raise HTTPException(404, "job not found")
        return record.model_dump()

    @app.post("/jobs/{job_id}/retry")
    async def retry_job(job_id: str):
        store: JobStore = app.state.store
        if store.get(job_id) is None:
            raise HTTPException(404, "job not found")
        if not _reserve():
            return _busy_conflict()
        cancel_event = asyncio.Event()
        app.state.job_cancel_events[job_id] = cancel_event
        _spawn_exclusive(_run(app, job_id, cancel_event, retry=True))
        return {"job_id": job_id, "status": "retrying"}

    @app.post("/jobs/{job_id}/cancel")
    async def cancel_job(job_id: str):
        store: JobStore = app.state.store
        record = store.get(job_id)
        if record is None:
            return JSONResponse(
                status_code=404,
                content={"detail": "작업을 찾을 수 없습니다.", "code": "JOB_NOT_FOUND"},
            )
        if record.status in _FINISHED_STATUSES:
            return JSONResponse(
                status_code=409,
                content={
                    "id": record.id,
                    "status": record.status,
                    "detail": "이미 종료된 작업입니다.",
                    "code": "JOB_ALREADY_FINISHED",
                },
            )
        # queued / running / cancel_requested -> signal the loop and mark the request.
        event = app.state.job_cancel_events.get(job_id)
        if event is not None:
            event.set()
        record.status = JobStatus.CANCEL_REQUESTED
        store.save(record)
        return {
            "id": record.id,
            "status": JobStatus.CANCEL_REQUESTED,
            "message": "작업 중지를 요청했습니다.",
        }

    @app.get("/jobs/{job_id}/download")
    async def download(job_id: str):
        store: JobStore = app.state.store
        record = store.get(job_id)
        if record is None:
            raise HTTPException(404, "job not found")
        out = store.output_path(job_id)
        if not out.exists():
            raise HTTPException(409, "output not ready")
        return FileResponse(
            out,
            filename=record.output_filename or "result.xlsx",
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    @app.exception_handler(KeyError)
    async def _key_error(_request, exc):
        return JSONResponse(status_code=404, content={"detail": str(exc)})

    return app


def _spawn(app: FastAPI, coro) -> None:
    task = asyncio.create_task(coro)
    app.state.tasks.add(task)
    task.add_done_callback(app.state.tasks.discard)


async def _run(app: FastAPI, job_id: str, cancel_event=None, retry: bool = False) -> None:
    try:
        await process_job(
            app.state.store,
            app.state.session_factory,
            job_id,
            retry_failed=retry,
            cancel_event=cancel_event,
        )
    except Exception as exc:  # noqa: BLE001 - never crash the worker on a job error
        record = app.state.store.get(job_id)
        if record is not None:
            record.status = JobStatus.FAILED
            record.current = None
            app.state.store.save(record)
        print(f"[job {job_id}] failed: {type(exc).__name__}: {exc}")
    finally:
        # Clean up the cancel signal so the next job starts fresh (spec §8).
        app.state.job_cancel_events.pop(job_id, None)
