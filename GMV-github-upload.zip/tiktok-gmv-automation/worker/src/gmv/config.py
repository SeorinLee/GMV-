"""Browser/market profiles for the US Chrome and UK Edge workflows."""

from __future__ import annotations

import os
from enum import Enum
from pathlib import Path

from pydantic import BaseModel


class ProfileStatus(str, Enum):
    """Connection lifecycle of a browser profile."""

    DISCONNECTED = "disconnected"
    LOGIN_REQUIRED = "login_required"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RUNNING = "running"
    EXPIRED = "expired"
    ERROR = "error"


# The real, confirmed navigation chain:
#   1. login entry   -> seller-us.tiktok.com/account/register
#   2. login success -> seller-us.tiktok.com/affiliate/landing?...
#   3. affiliate entry (target-invitation) -> affiliate-us.tiktok.com/connection/target-invitation
#   4. find creators  -> affiliate-us.tiktok.com/connection/creator
# Login (Seller Center) and lookup (Affiliate Center) are different hosts and must not be
# conflated: the affiliate pages render blank/loading without a session, which must never be
# treated as "logged in".
US_PROFILE_CODE = "US_CHROME"
UK_PROFILE_CODE = "UK_EDGE"

_US_LOGIN = "https://seller-us.tiktok.com/account/register"
_US_LOGIN_SUCCESS = (
    "https://seller-us.tiktok.com/affiliate/landing?is_new_connect=0&shop_region=US"
)
_US_AFFILIATE_ENTRY = "https://affiliate-us.tiktok.com/connection/target-invitation"
_US_FIND_CREATORS = "https://affiliate-us.tiktok.com/connection/creator"
# Legacy compatibility only — no longer part of the active flow.
_US_AFFILIATE = "https://affiliate-us.tiktok.com/platform/homepage?shop_region=US"

# UK uses a completely separate Edge persistent profile. Seller Center is region-specific,
# while the UK Creator Connection screen is served from the shared affiliate.tiktok.com host.
_UK_LOGIN = "https://seller-uk.tiktok.com/"
_UK_LOGIN_SUCCESS = (
    "https://seller-uk.tiktok.com/affiliate/landing?is_new_connect=0&shop_region=GB"
)
_UK_AFFILIATE_ENTRY = "https://affiliate.tiktok.com/connection/target-invitation"
_UK_FIND_CREATORS = "https://affiliate.tiktok.com/connection/creator"
_UK_AFFILIATE = "https://affiliate.tiktok.com/platform/homepage?shop_region=GB"


class BrowserProfile(BaseModel):
    """A single browser environment used for all jobs."""

    profile_code: str
    display_name: str
    browser_channel: str
    market: str
    shop_region: str
    login_url: str  # Seller Center login entry
    login_success_url: str  # where the user lands after a successful login
    affiliate_entry_url: str  # Affiliate Center entry (target-invitation)
    find_creators_url: str  # Find creators search page
    affiliate_url: str  # legacy/compat, not used in the active flow
    storage_key: str

    @property
    def storage_root(self) -> str:
        base = os.environ.get("GMV_PROFILE_ROOT", str(Path.cwd() / "storage" / "profiles"))
        return str(Path(base) / self.storage_key)


def get_default_profile() -> BrowserProfile:
    """Return the default Chrome/US profile; the home screen may explicitly choose UK/Edge."""
    return get_profile(os.environ.get("GMV_DEFAULT_PROFILE_CODE", US_PROFILE_CODE))


def _us_profile() -> BrowserProfile:
    return BrowserProfile(
        profile_code=US_PROFILE_CODE,
        display_name=os.environ.get("GMV_US_PROFILE_NAME", "Chrome · United States"),
        browser_channel=os.environ.get("GMV_BROWSER_CHANNEL", "chrome"),
        market="US",
        shop_region="US",
        login_url=os.environ.get("GMV_LOGIN_URL", _US_LOGIN),
        login_success_url=os.environ.get("GMV_LOGIN_SUCCESS_URL", _US_LOGIN_SUCCESS),
        affiliate_entry_url=os.environ.get("GMV_AFFILIATE_ENTRY_URL", _US_AFFILIATE_ENTRY),
        find_creators_url=os.environ.get("GMV_FIND_CREATORS_URL", _US_FIND_CREATORS),
        affiliate_url=os.environ.get("GMV_AFFILIATE_URL", _US_AFFILIATE),
        # Reuse the former DEFAULT directory so the user's current Chrome login survives upgrade.
        storage_key=os.environ.get("GMV_US_PROFILE_STORAGE_KEY", "DEFAULT"),
    )


def _uk_profile() -> BrowserProfile:
    return BrowserProfile(
        profile_code=UK_PROFILE_CODE,
        display_name=os.environ.get("GMV_UK_PROFILE_NAME", "Edge · United Kingdom"),
        browser_channel=os.environ.get("GMV_UK_BROWSER_CHANNEL", "msedge"),
        market="UK",
        shop_region="GB",
        login_url=os.environ.get("GMV_UK_LOGIN_URL", _UK_LOGIN),
        login_success_url=os.environ.get("GMV_UK_LOGIN_SUCCESS_URL", _UK_LOGIN_SUCCESS),
        affiliate_entry_url=os.environ.get("GMV_UK_AFFILIATE_ENTRY_URL", _UK_AFFILIATE_ENTRY),
        find_creators_url=os.environ.get("GMV_UK_FIND_CREATORS_URL", _UK_FIND_CREATORS),
        affiliate_url=os.environ.get("GMV_UK_AFFILIATE_URL", _UK_AFFILIATE),
        storage_key=os.environ.get("GMV_UK_PROFILE_STORAGE_KEY", UK_PROFILE_CODE),
    )


def get_profile(profile_code: str) -> BrowserProfile:
    """Resolve a UI/API profile code, keeping ``DEFAULT`` as a legacy US alias."""
    key = str(profile_code or "").strip().upper()
    if key in {US_PROFILE_CODE, "DEFAULT", "US", "CHROME"}:
        return _us_profile()
    if key in {UK_PROFILE_CODE, "UK", "GB", "EDGE"}:
        return _uk_profile()
    raise KeyError(profile_code)


def list_profiles() -> list[BrowserProfile]:
    return [_us_profile(), _uk_profile()]


# Column headers that may carry a per-row market (kept for compatibility but ignored).
ACCOUNT_COLUMN_ALIASES = {"market", "region", "account", "shopregion", "국가", "마켓"}


def resolve_profile_code(value: object) -> str | None:
    """Resolve optional spreadsheet region hints to one of the two browser profiles."""
    key = str(value or "").strip().lower().replace(" ", "").replace("_", "")
    if not key:
        return None
    us = {
        "us",
        "usa",
        "unitedstates",
        "미국",
        "chrome",
        "us_chrome",
        "uschrome",
        "default",
    }
    uk = {
        "uk",
        "gb",
        "unitedkingdom",
        "영국",
        "edge",
        "uk_edge",
        "ukedge",
    }
    if key in us:
        return US_PROFILE_CODE
    if key in uk:
        return UK_PROFILE_CODE
    return None
