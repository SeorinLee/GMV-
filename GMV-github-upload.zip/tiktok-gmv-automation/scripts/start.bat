@echo off
REM One-click local start: Worker (TikTok automation) + Web (Next.js).
REM End users never touch this — it is for the operator hosting the app locally.
REM The Web app is launched ONLY after the Worker reports healthy (spec §18).

setlocal
set ROOT=%~dp0..
set WORKER=%ROOT%\worker
set WEB=%ROOT%\apps\web

REM ---- Preconditions ---------------------------------------------------------
if not exist "%WORKER%\.venv\Scripts\python.exe" (
  echo Worker 가상환경이 없습니다.
  echo worker 폴더에서 다음 명령을 먼저 실행하세요:
  echo.
  echo     py -m venv .venv
  echo     .\.venv\Scripts\python.exe -m pip install -e ".[dev]"
  echo.
  pause
  exit /b 1
)

if not exist "%WEB%\node_modules" (
  echo Web 의존성이 설치되지 않았습니다.
  echo apps\web 폴더에서 npm install을 실행하세요.
  echo.
  pause
  exit /b 1
)

REM ---- Start the Worker ------------------------------------------------------
echo Starting GMV Worker...
start "GMV Worker" cmd /k "cd /d %WORKER% && .venv\Scripts\python.exe -m gmv.worker_main"

REM ---- Wait for the Worker to become healthy (max 60s) -----------------------
echo Waiting for Worker health at http://127.0.0.1:8000/health ...
set /a TRIES=0
:waitloop
curl -s -o nul -f http://127.0.0.1:8000/health
if %ERRORLEVEL%==0 goto ready
set /a TRIES+=1
if %TRIES% GEQ 60 goto timeout
timeout /t 1 >nul
goto waitloop

:timeout
echo.
echo Worker 서버가 60초 안에 준비되지 않았습니다.
echo Worker 창의 오류 메시지를 확인하세요.
echo.
pause
exit /b 1

:ready
echo Worker is healthy.

REM ---- Start the Web app -----------------------------------------------------
echo Starting GMV Web...
start "GMV Web" cmd /k "cd /d %WEB% && npm run dev"

REM ---- Wait for the Web app to answer (max 60s), then open the browser -------
echo Waiting for Web at http://localhost:3000 ...
set /a TRIES=0
:webloop
curl -s -o nul http://localhost:3000
if %ERRORLEVEL%==0 goto webready
set /a TRIES+=1
if %TRIES% GEQ 60 goto webready
timeout /t 1 >nul
goto webloop

:webready
start http://localhost:3000
echo Opened http://localhost:3000
endlocal
