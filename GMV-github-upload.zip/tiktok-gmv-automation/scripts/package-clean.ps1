<#
.SYNOPSIS
  Build a clean distributable source ZIP of the project (spec §19).

.DESCRIPTION
  Copies the source tree into a staging folder, EXCLUDING build artifacts, virtualenvs,
  browser profiles, credential files and user Excel data, then zips it. Never touches the
  working tree. Output: dist/tiktok-gmv-automation-clean.zip

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File scripts\package-clean.ps1
#>

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$distDir = Join-Path $root "dist"
$staging = Join-Path $distDir "tiktok-gmv-automation"
$zipPath = Join-Path $distDir "tiktok-gmv-automation-clean.zip"

# Directory names excluded anywhere in the tree.
$excludeDirs = @(
  ".git", "node_modules", ".next", ".venv", "venv",
  ".pytest_cache", ".ruff_cache", ".mypy_cache", "__pycache__",
  ".vercel", "dist", "storage", "profiles", ".tiktok_profile"
)

# File names / patterns excluded anywhere in the tree.
$excludeFiles = @(
  "*.pyc", "desktop.ini", "Thumbs.db", ".DS_Store",
  "tiktok_state.json", "*_state.json", "Cookies", "Login Data",
  "*.tsbuildinfo", "*_GMV완료_*.xlsx", "manager_filled.xlsx"
)

# The upload template is the ONE .xlsx we keep; every other .xlsx (user data) is dropped.
$keepXlsx = "gmv_upload_template.xlsx"

if (Test-Path $staging) { Remove-Item -Recurse -Force $staging }
if (Test-Path $zipPath) { Remove-Item -Force $zipPath }
New-Item -ItemType Directory -Force -Path $staging | Out-Null

function Test-ExcludedFile($name) {
  # Keep only the template among .xlsx files.
  if ($name -like "*.xlsx" -and $name -ne $keepXlsx) { return $true }
  foreach ($pattern in $excludeFiles) {
    if ($name -like $pattern) { return $true }
  }
  return $false
}

# Depth-first walk that PRUNES excluded directories (never descends into node_modules/.venv/.git).
$script:copied = 0
function Copy-Tree($dir) {
  foreach ($item in Get-ChildItem -LiteralPath $dir -Force) {
    if ($item.FullName.StartsWith($distDir)) { continue }
    if ($item.PSIsContainer) {
      if ($excludeDirs -contains $item.Name) { continue }
      Copy-Tree $item.FullName
      continue
    }
    if (Test-ExcludedFile $item.Name) { continue }

    $rel = $item.FullName.Substring($root.Length).TrimStart('\', '/')
    $dest = Join-Path $staging $rel
    $destDir = Split-Path -Parent $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }
    Copy-Item -LiteralPath $item.FullName -Destination $dest -Force
    $script:copied++
  }
}

Copy-Tree $root
$copied = $script:copied

Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zipPath -Force
Remove-Item -Recurse -Force $staging

Write-Host "Packaged $copied files -> $zipPath"
