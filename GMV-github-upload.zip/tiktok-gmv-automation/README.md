# TikTok Shop Affiliate GMV Automation

Upload an Excel of creators → pick a market account (US Chrome / UK Edge) → the system
searches each creator in TikTok Shop Affiliate Center, reads GMV (range values converted to
their max), writes it back into the **original workbook with formatting preserved**, and lets
you download the finished file. No terminal, no Python, no manual Excel editing.

## Architecture

```
apps/web/     Next.js website — upload, account select, live progress, download, retry
worker/       Python — GMV parser, Excel engine, Playwright automation (Chrome+Edge), API
supabase/     Postgres schema + RLS migrations (auth + durable job state)
docker/       Worker image (Chrome + Edge + Playwright)
docs/         decisions.md, deployment.md
```

Browser automation and Excel processing run in the **Worker** (needs real Chrome + Edge);
Vercel hosts only the Next.js site (spec §8). For the MVP the web app talks directly to the
Worker's HTTP API; Supabase adds auth + multi-user durable state.

## What is verified vs. not

**Verified (unit / mock-E2E tested, 113 passing):** GMV parsing (exact/K/M/B/range-max/
open-ended), creator normalization + exact matching, format-preserving Excel read/write,
column detection incl. Korean, dedupe, US/UK profile isolation, job dedupe/split/retry,
and the upload→process→download→retry API flow (with a fake browser session).

**NOT verified (needs your real account + host):** live TikTok Affiliate Center DOM
selectors and network shapes, real GMV values, login/CAPTCHA/2FA, the UK affiliate host,
and Supabase/Vercel deployment. See `docs/decisions.md` → UNVERIFIED.

## Quick start (local, single PC with Chrome + Edge)

```powershell
# 1) Worker
cd worker
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m playwright install chrome msedge
.\.venv\Scripts\python.exe -m gmv.worker_main        # :8000

# 2) Web (separate terminal)
cd apps/web
npm install
npm run dev                                           # :3000
```

Then open http://localhost:3000, log into each account once, upload an Excel, pick the
account, and run.

See `docs/deployment.md` for production (dedicated Worker host + Vercel + Supabase).
