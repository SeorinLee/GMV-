"""Playwright driver for one Affiliate Center account (spec §6, §9, §11).

One persistent browser context per profile is launched ONCE and reused for every creator in
a job (browser/context/page/search screen reused — spec §11). Fixed sleeps are replaced with
event-based waits. Username is verified before any GMV is recorded (spec §16), and a result
signature guards against saving a stale previous result (spec §11).

Playwright is imported lazily so pure modules/tests do not require it.

NOTE: selectors and network shapes are UNVERIFIED against the live DOM (D10) — validate
against a logged-in session before production use.
"""

from __future__ import annotations

import asyncio
import contextlib
import re
from datetime import UTC, datetime

from gmv.automation import selectors
from gmv.config import BrowserProfile, ProfileStatus
from gmv.creator import normalize_username, usernames_match
from gmv.gmv_parser import parse_gmv
from gmv.models import ErrorCode, GmvValueType, JobCancelledError, LookupResult, RowStatus

SEARCH_TIMEOUT_MS = 15_000
NAV_TIMEOUT_MS = 10_000
ENTRY_READY_TIMEOUT_MS = 20_000  # SPA pages settle late; wait on a real DOM element
SEARCH_READY_TIMEOUT_MS = 20_000


class AffiliateEntryNotReadyError(Exception):
    """The Affiliate Center entry (target-invitation) did not render in time."""


class SearchPageNotFoundError(Exception):
    """The Find-creators page loaded but its search input never appeared."""


class AffiliateSessionExpiredError(Exception):
    """An Affiliate-Center navigation was redirected to a login/account page mid-job."""


class CreatorOpenFailedError(Exception):
    """Clicking a result row / view-details control to open the creator failed."""


class CreatorDetailTimeoutError(Exception):
    """The creator detail panel did not appear within the timeout."""


class SelectorError(Exception):
    """A selector/locator method raised while querying the DOM."""


class AutocompleteClickFailedError(Exception):
    """Clicking the matched autocomplete suggestion failed."""


# Pipeline stages recorded on each row so a failure says WHERE it happened (spec §1).
STAGE_SEARCH_INPUT = "SEARCH_INPUT"
STAGE_WAIT_AUTOCOMPLETE = "WAIT_AUTOCOMPLETE"
STAGE_WAIT_SEARCH_RESULTS = "WAIT_SEARCH_RESULTS"
STAGE_MATCH_USERNAME = "MATCH_USERNAME"
STAGE_OPEN_CREATOR = "OPEN_CREATOR"
STAGE_WAIT_GMV = "WAIT_GMV"
STAGE_EXTRACT_GMV = "EXTRACT_GMV"

# Fast defaults: successful rows return as soon as the table renders. These limits mainly cap
# failures, so reducing them removes long dead time without adding a fixed delay to good rows.
DETAIL_TIMEOUT_MS = 5_000
AUTOCOMPLETE_TIMEOUT_MS = 2_500
SEARCH_RESULTS_TIMEOUT_MS = 10_000

_GMV_TYPE_LABELS = {
    GmvValueType.EXACT: "exact",
    GmvValueType.RANGE_MAX: "range_upper",
    GmvValueType.OPEN_ENDED_ESTIMATE: "open_ended",
    GmvValueType.NOT_FOUND: "not_found",
    GmvValueType.ERROR: "error",
}


class _AcInfo:
    """What the autocomplete stage observed (used to choose a precise error)."""

    def __init__(self):
        self.saw_panel = False
        self.saw_suggestions = False
        self.saw_username = False


_HAS_DIGIT = re.compile(r"\d")


def _looks_like_money(text: str) -> bool:
    """A money-ish value: has a currency mark or at least one digit (e.g. $1.2K, $0-$5K, 1234)."""
    t = (text or "").strip()
    return bool(t) and ("$" in t or "€" in t or "£" in t or bool(_HAS_DIGIT.search(t)))


def _looks_like_count(text: str) -> bool:
    return bool(_HAS_DIGIT.search(text or ""))


def _safe_exc(exc: Exception) -> str:
    """Bounded, sanitized exception text — strip URLs (which may carry query/tokens), §1/§8."""
    msg = re.sub(r"https?://\S+", "[url]", str(exc))
    return msg[:300]


def _fail(result: LookupResult, code: ErrorCode, message: str | None = None) -> LookupResult:
    result.status = RowStatus.FAILED
    result.error_code = code
    if message:
        result.error_message = message[:300]
    return result


_HANDLE_RE = re.compile(r"[A-Za-z0-9._]+")


def _username_from_text(text: str | None) -> str | None:
    """Isolate a username handle from row text that may include extra labels/names (§4).

    Handles ``@arlynvibes``, ``arlynvibes`` and ``Creator: arlynvibes``. Prefers an ``@handle``
    token; otherwise the segment after a colon, else the first handle-like token. Returns a bare
    handle (matching is done by :func:`usernames_match`, which normalizes both sides).
    """
    t = (text or "").replace("​", "").strip()
    if not t:
        return None
    at = re.search(r"@([A-Za-z0-9._]+)", t)
    if at:
        return at.group(1)
    if ":" in t:
        t = t.split(":")[-1].strip()
    for token in t.split():
        m = _HANDLE_RE.fullmatch(token.strip().lstrip("@"))
        if m:
            return m.group(0)
    return None


def _parse_count(text: str | None) -> int | None:
    """Expand a count and use the maximum for ranges (``0-100`` -> ``100``)."""
    t = (text or "").strip().lower().replace(",", "")
    values: list[int] = []
    for match in re.finditer(r"(\d+(?:\.\d+)?)\s*([km])?", t):
        num = float(match.group(1))
        unit = match.group(2)
        if unit == "k":
            num *= 1_000
        elif unit == "m":
            num *= 1_000_000
        values.append(int(num))
    if not values:
        return None
    return max(values)


# A line that is ONLY a count (optionally with K/M) — used for Items sold (spec §2, §7).
_ITEMS_RE = re.compile(r"^\d[\d,]*(?:\.\d+)?[km]?$", re.IGNORECASE)

# Capture only the money token from a result row. This avoids feeding profile numbers such as
# PPS, followers and audience percentages into the GMV parser when a table renders as one line.
_MONEY_TOKEN_RE = re.compile(
    r"([$€£]\s*\d[\d,]*(?:\.\d+)?\s*[kmb]?"
    r"(?:\s*(?:-|–|—|to)\s*[$€£]?\s*\d[\d,]*(?:\.\d+)?\s*[kmb]?)?\s*\+?)",
    re.IGNORECASE,
)

# The first standalone count after the GMV cell is Items sold in the confirmed table layout.
_COUNT_TOKEN_RE = re.compile(
    r"(?<![\dA-Za-z._])(\d[\d,]*(?:\.\d+)?\s*[km]?"
    r"(?:\s*(?:-|–|—|to)\s*\d[\d,]*(?:\.\d+)?\s*[km]?)?)(?![\dA-Za-z._])",
    re.IGNORECASE,
)


def _items_from_line(line: str | None) -> int | None:
    s = (line or "").strip()
    if not s or "$" in s:
        return None
    if not _ITEMS_RE.fullmatch(s.replace(" ", "")):
        return None
    return _parse_count(s)


def _normalize_text(text: str | None) -> str:
    return (text or "").replace("​", "").lower()


async def find_first_visible(
    root,
    selector_candidates: list[str],
    *,
    timeout_ms: int = SEARCH_TIMEOUT_MS,
):
    """Return the first visible locator among heterogeneous selector candidates.

    CSS selectors and Playwright text= selectors must NOT be comma-joined (spec §15). Each
    candidate is tried on its own, in order, so a bad candidate never breaks the group.
    """
    # Fast path for elements already rendered. Previously the first missing selector could cost
    # one full second even when the second candidate was already visible.
    for selector in selector_candidates:
        locator = root.locator(selector).first
        try:
            if await locator.count() > 0 and await locator.is_visible():
                return locator
        except Exception:  # noqa: BLE001
            continue

    per = max(250, timeout_ms // max(1, len(selector_candidates)))
    for selector in selector_candidates:
        locator = root.locator(selector).first
        try:
            await locator.wait_for(state="visible", timeout=per)
            return locator
        except Exception:  # noqa: BLE001
            continue
    return None


async def find_all_matching(root, selector_candidates: list[str]) -> list:
    """Return every element matched by any candidate selector, checked individually (spec §15)."""
    found: list = []
    for selector in selector_candidates:
        with contextlib.suppress(Exception):
            found.extend(await root.locator(selector).all())
    return found


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class TikTokAffiliateSession:
    """Drives one market's Affiliate Center. Create, ``start``, ``search_creator`` N times, ``close``."""

    def __init__(self, profile: BrowserProfile, headless: bool = False):
        self.profile = profile
        self.headless = headless
        self._pw = None
        self._context = None
        self._page = None
        self._captured_json: list = []
        self._search_box = None  # the search input locator, reused for the table fallback
        # Set by the runner before a job; a set() event means the user asked to stop (§6).
        self.cancel_event = None

    def _check_cancel(self) -> None:
        if self.cancel_event is not None and self.cancel_event.is_set():
            raise JobCancelledError

    async def start(self) -> ProfileStatus:
        from playwright.async_api import async_playwright

        self._check_cancel()  # before launching the browser (§6)
        self._pw = await async_playwright().start()
        # Dedicated persistent context per profile -> isolated cookies/storage (spec §6).
        self._context = await self._pw.chromium.launch_persistent_context(
            user_data_dir=self.profile.storage_root,
            channel=self.profile.browser_channel,
            headless=self.headless,
        )
        self._page = self._context.pages[0] if self._context.pages else await self._context.new_page()
        self._page.on("response", self._on_response)
        # Reuse the existing Seller Center session and go STRAIGHT to the creator page — no
        # target-invitation step (spec §1, §3). Login is never reopened here.
        await self._page.goto(self.profile.find_creators_url, wait_until="domcontentloaded")
        self._log_step("find-creators")
        return await self.check_login()

    def _log_step(self, step: str) -> None:
        """Log only step + hostname + pathname — never query strings, cookies or tokens (§8)."""
        from urllib.parse import urlparse

        parsed = urlparse(self._page.url if self._page else "")
        print(f"[{step}] host={parsed.hostname} path={parsed.path}")

    async def _on_response(self, response) -> None:
        ctype = response.headers.get("content-type", "")
        if "application/json" not in ctype:
            return
        with contextlib.suppress(Exception):
            self._captured_json.append(await response.json())
        # Keep only the most recent handful to bound memory.
        if len(self._captured_json) > 20:
            self._captured_json = self._captured_json[-20:]

    async def check_login(self) -> ProfileStatus:
        if self._page is None:
            return ProfileStatus.DISCONNECTED
        # On the Affiliate Center, a redirect to any account/login page means no session (§7).
        if selectors.is_affiliate_login_redirect(self._page.url):
            return ProfileStatus.LOGIN_REQUIRED
        return ProfileStatus.CONNECTED

    async def search_creator(self, requested: str) -> LookupResult:
        norm = normalize_username(requested)
        result = LookupResult(
            normalized_username=norm or requested,
            account_label=self.profile.profile_code,
            queried_at=_now_iso(),
        )
        if norm is None:
            result.status = RowStatus.FAILED
            result.error_code = ErrorCode.PARSE_ERROR
            result.error_message = "empty username"
            return result

        try:
            self._check_cancel()  # before starting this creator (§6)
            if selectors.is_affiliate_login_redirect(self._page.url):
                result.status = RowStatus.FAILED
                result.error_code = ErrorCode.SESSION_EXPIRED
                return result

            result.current_stage = STAGE_SEARCH_INPUT
            self._captured_json.clear()
            try:
                search = await self.ensure_find_creators_page()
            except AffiliateSessionExpiredError:
                return _fail(result, ErrorCode.SESSION_EXPIRED, "creator page redirected to login")
            except SearchPageNotFoundError:
                return _fail(
                    result, ErrorCode.SEARCH_PAGE_NOT_FOUND, "search input not found on creator page"
                )

            await search.click()
            await search.press("Control+A")
            await search.press("Delete")
            await search.fill(norm)
            self._search_box = search
            # Do NOT press Enter yet — wait for the autocomplete dropdown first (spec §2).
            return await self._identify_and_extract(norm, result)
        except JobCancelledError:
            raise  # cooperative cancel must propagate, never become a row error
        except CreatorOpenFailedError as exc:
            return _fail(result, ErrorCode.CREATOR_OPEN_FAILED, _safe_exc(exc))
        except CreatorDetailTimeoutError as exc:
            return _fail(result, ErrorCode.CREATOR_DETAIL_TIMEOUT, _safe_exc(exc))
        except SelectorError as exc:
            return _fail(result, ErrorCode.SELECTOR_ERROR, _safe_exc(exc))
        except Exception as exc:  # noqa: BLE001 — only truly unexpected Playwright errors land here
            # Preserve the exception TYPE + a bounded, safe message (no cookies/tokens/URLs, §1).
            return _fail(result, ErrorCode.BROWSER_ERROR, f"{type(exc).__name__}: {_safe_exc(exc)}")

    async def _has_search_input(self):
        """Return the search-input locator if one is already visible, else None."""
        return await find_first_visible(self._page, selectors.SEARCH_INPUT, timeout_ms=2000)

    async def _wait_visible_or_cancel(self, selector_candidates: list[str], timeout_ms: int):
        """Poll for a visible element in short slices so a cancel is honored fast (§6).

        Never uses one long wait_for — checks the cancel event between ~0.5s probes so a stop
        request is not delayed by a 20-30s Playwright timeout.
        """
        deadline = timeout_ms / 1000
        waited = 0.0
        while waited < deadline:
            self._check_cancel()
            element = await find_first_visible(self._page, selector_candidates, timeout_ms=500)
            if element is not None:
                return element
            await asyncio.sleep(0.2)
            waited += 0.7
        return None

    async def ensure_find_creators_page(self):
        """Reach the Find-creators search page and return its search-input locator.

        Simplified flow (spec §1, §3): reuse the current search input if present → otherwise go
        STRAIGHT to the creator page (no target-invitation) → wait (cancel-aware, event-based) up
        to ~20s for the search input. If TikTok itself bounces us elsewhere (e.g. an interstitial
        redirect), retry the creator URL exactly ONCE before giving up — no infinite retries.

        Raises:
            AffiliateSessionExpiredError: a navigation was redirected to a login/account page.
            SearchPageNotFoundError: the creator page rendered but has no search input.
        """
        search = await self._has_search_input()
        if search is not None:
            return search

        self._check_cancel()  # before navigating to the creator page (§6)
        await self._page.goto(self.profile.find_creators_url, wait_until="domcontentloaded")
        self._log_step("find-creators")
        if selectors.is_affiliate_login_redirect(self._page.url):
            raise AffiliateSessionExpiredError

        search = await self._wait_visible_or_cancel(
            selectors.SEARCH_INPUT, timeout_ms=SEARCH_READY_TIMEOUT_MS
        )
        if search is not None:
            return search

        # TikTok may auto-redirect the creator URL to an interstitial (e.g. target-invitation).
        # Let it settle briefly, then re-navigate to the creator URL exactly once.
        await asyncio.sleep(1.0)
        self._check_cancel()
        if selectors.is_affiliate_login_redirect(self._page.url):
            raise AffiliateSessionExpiredError
        await self._page.goto(self.profile.find_creators_url, wait_until="domcontentloaded")
        self._log_step("find-creators-retry")
        if selectors.is_affiliate_login_redirect(self._page.url):
            raise AffiliateSessionExpiredError

        search = await self._wait_visible_or_cancel(
            selectors.SEARCH_INPUT, timeout_ms=SEARCH_READY_TIMEOUT_MS
        )
        if search is None:
            raise SearchPageNotFoundError
        return search

    async def _identify_and_extract(self, norm: str, result: LookupResult) -> LookupResult:
        """Select the creator (autocomplete), then read GMV/Items sold from the results row text.

        Simplified to match the proven Python approach: after the autocomplete suggestion is
        clicked (or Enter is pressed), find the creator's username on the Search-results screen,
        walk up its ancestor containers to the smallest one holding the username AND a ``$``, and
        parse GMV + Items sold from that row's text. The detail drawer is only a fallback and never
        raises CREATOR_DETAIL_TIMEOUT to the row.
        """
        result.current_stage = STAGE_WAIT_AUTOCOMPLETE
        suggestion, ac = await self._match_autocomplete(norm)
        if suggestion is not None:
            try:
                result.current_stage = STAGE_OPEN_CREATOR
                await self._click_open(suggestion, ErrorCode.AUTOCOMPLETE_CLICK_FAILED)
            except JobCancelledError:
                raise
            except AutocompleteClickFailedError as exc:
                return _fail(result, ErrorCode.AUTOCOMPLETE_CLICK_FAILED, _safe_exc(exc))
        elif self._search_box is not None:
            # Some TikTok builds filter the table while typing. Only press Enter if a completed
            # matching row is not already present, then let the single row-wait below do the rest.
            existing = await self._row_text_from_result_rows(norm)
            if existing is None:
                with contextlib.suppress(Exception):
                    await self._search_box.press("Enter")
        return await self._extract_by_row_text(norm, result, ac)

    async def _extract_by_row_text(self, norm, result, ac) -> LookupResult:
        # Clicking an autocomplete option returns before TikTok finishes rendering the table.
        # Poll for the actual row containing BOTH this username and a money value; otherwise the
        # old code could immediately grab the still-open suggestion card and report a false fail.
        result.current_stage = STAGE_WAIT_SEARCH_RESULTS
        self._check_cancel()
        row_text, any_text, saw_username = await self._wait_for_creator_row_text(norm)
        if row_text is None and any_text is None:
            if saw_username:
                return _fail(result, ErrorCode.RESULT_ROW_NOT_FOUND, "username found, no readable row")
            if ac.saw_suggestions and not ac.saw_username:
                return _fail(result, ErrorCode.AUTOCOMPLETE_USERNAME_NOT_FOUND, "dropdown, no handle")
            if ac.saw_suggestions:
                return _fail(result, ErrorCode.AUTOCOMPLETE_MISMATCH, f"no match for {norm}")
            return _fail(result, ErrorCode.CREATOR_NOT_FOUND, f"'{norm}' not on results screen")

        result.current_stage = STAGE_EXTRACT_GMV
        text = row_text or any_text or ""
        gmv_raw, items_raw, items_val = self._parse_row_text(text)
        source = "row_text"

        # Fallback to the detail drawer/panel ONLY if the row text had no GMV (never times out).
        if gmv_raw is None:
            panel_raw, panel_items = await self._detail_fallback()
            if panel_raw is not None:
                gmv_raw, source = panel_raw, "detail_panel"
                if items_val is None:
                    items_val = panel_items

        self._log_gmv_row(norm, text, gmv_raw, items_raw, items_val)

        if gmv_raw is None:
            self._log_extraction_failed(ErrorCode.GMV_NOT_FOUND.value)
            return _fail(result, ErrorCode.GMV_NOT_FOUND, "no $ line in row and no detail GMV")

        parsed = parse_gmv(gmv_raw)
        if parsed.value_type in (GmvValueType.NOT_FOUND, GmvValueType.ERROR):
            self._log_extraction_failed(ErrorCode.GMV_PARSE_ERROR.value)
            return _fail(result, ErrorCode.GMV_PARSE_ERROR, f"unparseable GMV: {gmv_raw[:60]}")

        result.gmv = parsed
        result.items_sold = items_val  # None if not found -- a missing count never fails a good GMV
        result.items_sold_raw = items_raw
        result.source = source
        result.status = (
            RowStatus.RANGE
            if parsed.value_type in (GmvValueType.RANGE_MAX, GmvValueType.OPEN_ENDED_ESTIMATE)
            else RowStatus.SUCCESS
        )
        self._log_extraction_success(source)
        return result

    async def _find_creator_elements(self, norm: str) -> list:
        """Return visible username elements; do not blindly take the first autocomplete match."""
        found: list = []
        for exact in (True, False):
            for candidate in (norm, "@" + norm):
                with contextlib.suppress(Exception):
                    loc = self._page.get_by_text(candidate, exact=exact)
                    for element in await loc.all():
                        if await element.is_visible() and element not in found:
                            found.append(element)
            if found:
                break
        return found

    async def _row_text_from_result_rows(self, norm: str) -> str | None:
        """Read the confirmed Creator/GMV/Items-sold table row directly when possible."""
        candidates = selectors.SEARCH_RESULT_ROWS + selectors.RESULT_ROW
        for row in await find_all_matching(self._page, candidates):
            with contextlib.suppress(Exception):
                if not await row.is_visible():
                    continue
                text = await row.inner_text()
                if norm in _normalize_text(text) and _MONEY_TOKEN_RE.search(text):
                    return text
        return None

    async def _wait_for_creator_row_text(self, norm: str):
        """Wait for a real result row instead of racing the SPA after the suggestion click."""
        deadline = SEARCH_RESULTS_TIMEOUT_MS / 1000
        waited = 0.0
        last_any = None
        saw_username = False
        while waited < deadline:
            self._check_cancel()

            direct = await self._row_text_from_result_rows(norm)
            if direct is not None:
                return direct, direct, True

            elements = await self._find_creator_elements(norm)
            saw_username = saw_username or bool(elements)
            for element in elements:
                row_text, any_text = await self._row_text_from_ancestors(element, norm)
                if row_text is not None:
                    return row_text, any_text, True
                if any_text is not None:
                    last_any = any_text

            await asyncio.sleep(0.15)
            waited += 0.15
        return None, last_any, saw_username

    async def _row_text_from_ancestors(self, element, norm: str):
        """Return the smallest table/role/div ancestor containing username and a money token."""
        any_text = None
        ancestor_selectors = [
            "xpath=ancestor::tr[1]",
            "xpath=ancestor::*[@role='row'][1]",
            *[f"xpath=ancestor::div[{level}]" for level in range(1, 17)],
        ]
        for selector in ancestor_selectors:
            self._check_cancel()
            try:
                ancestor = element.locator(selector)
                text = await ancestor.inner_text()
            except Exception:  # noqa: BLE001 -- ran out of ancestors / not readable
                continue
            if not text or norm not in _normalize_text(text):
                continue
            if any_text is None:
                any_text = text
            if _MONEY_TOKEN_RE.search(text):
                return text, any_text
        return None, any_text

    def _parse_row_text(self, text: str):
        """Return (gmv_raw, items_sold_raw, items_sold_value) from a row's text (spec 2)."""
        clean = (text or "").replace("\xa0", " ")
        money = _MONEY_TOKEN_RE.search(clean)
        gmv_raw = money.group(1).strip() if money else None
        items_raw = None
        items_val = None
        if money is not None:
            # The table order is GMV -> Items sold -> Avg. views. Keep the search close to GMV
            # and take the first standalone count after it.
            count = _COUNT_TOKEN_RE.search(clean[money.end() : money.end() + 160])
            if count is not None:
                items_raw = count.group(1).replace(" ", "")
                items_val = _parse_count(items_raw)
        return gmv_raw, items_raw, items_val

    async def _detail_fallback(self):
        """Best-effort GMV from a detail drawer/panel; returns (None, None) on timeout (no raise)."""
        try:
            panel = await self._wait_detail_ready()
        except JobCancelledError:
            raise
        except CreatorDetailTimeoutError:
            return None, None
        _, raw = await self._scoped_money(panel, selectors.GMV_LABELS, selectors.GMV_VALUES)
        items = await self._scoped_items(panel)
        return raw, items

    def _log_gmv_row(self, creator, text, gmv_raw, items_raw, items_val) -> None:
        """Print the read row to the Worker terminal (safe fields only, row_text <=500)."""
        joined = " | ".join(x.strip() for x in text.split("\n") if x.strip())[:500]
        print(f"[gmv-row] creator={creator}")
        print(f"[gmv-row] row_text={joined}")
        if gmv_raw:
            parsed = parse_gmv(gmv_raw)
            print(f"[gmv-row] gmv_raw={gmv_raw}")
            print(f"[gmv-row] gmv_value={parsed.value}")
            print(f"[gmv-row] gmv_type={_GMV_TYPE_LABELS.get(parsed.value_type, 'unknown')}")
        if items_raw:
            print(f"[gmv-row] items_sold_raw={items_raw}")
            print(f"[gmv-row] items_sold_value={items_val}")

    def _log_extraction_success(self, source: str) -> None:
        print(f"[gmv-row] extraction=success source={source}")

    def _log_extraction_failed(self, reason: str) -> None:
        print(f"[gmv-row] extraction=failed reason={reason}")

    async def _match_autocomplete(self, norm: str):
        """Wait for the dropdown and return (exact_suggestion_or_None, _AcInfo)."""
        info = _AcInfo()
        suggestions, info.saw_panel = await self._wait_autocomplete(norm)
        info.saw_suggestions = bool(suggestions)
        for sug in suggestions:
            handle = await self._username_in_scope(sug, selectors.AUTOCOMPLETE_USERNAME)
            if handle is None:
                # No dedicated handle element — fall back to the suggestion's own text (§3).
                with contextlib.suppress(Exception):
                    handle = _username_from_text(await sug.inner_text())
            if handle is not None:
                info.saw_username = True
                if usernames_match(norm, handle):
                    return sug, info
        return None, info

    async def _wait_autocomplete(self, norm: str):
        """Poll (cancel-aware) for suggestion cards; return (suggestions, saw_panel)."""
        rendered = selectors.render_autocomplete_suggestions(norm)
        deadline = AUTOCOMPLETE_TIMEOUT_MS / 1000
        waited = 0.0
        saw_panel = False
        while waited < deadline:
            self._check_cancel()  # a stop must work while waiting for the dropdown (§6)
            suggestions = await find_all_matching(self._page, rendered)
            visible = []
            for suggestion in suggestions:
                with contextlib.suppress(Exception):
                    if await suggestion.is_visible():
                        visible.append(suggestion)
            if visible:
                return visible, True

            # Observe panel presence without a sequential wait across broad fallback selectors.
            if not saw_panel:
                for selector in selectors.AUTOCOMPLETE_PANEL:
                    with contextlib.suppress(Exception):
                        panel = self._page.locator(selector).first
                        if await panel.count() > 0 and await panel.is_visible():
                            saw_panel = True
                            break

            await asyncio.sleep(0.1)
            waited += 0.1
        return [], saw_panel

    async def _click_open(self, target, click_error) -> None:
        """Click ``target`` to open the creator; raise the appropriate open/click error."""
        el = await find_first_visible(target, selectors.RESULT_ROW_CLICK_TARGET, timeout_ms=1000)
        if el is None:
            el = await find_first_visible(target, selectors.AUTOCOMPLETE_CLICK_TARGET, timeout_ms=500)
        if el is None:
            el = target
        try:
            await el.click()
        except Exception as exc:  # noqa: BLE001
            if click_error is ErrorCode.AUTOCOMPLETE_CLICK_FAILED:
                raise AutocompleteClickFailedError(_safe_exc(exc)) from exc
            raise CreatorOpenFailedError(_safe_exc(exc)) from exc

    async def _username_in_scope(self, scope, selector_list) -> str | None:
        """Extract a username from WITHIN a scope (row or suggestion), never the page, §4."""
        for selector in selector_list:
            try:
                loc = scope.locator(selector).first
                if await loc.count() == 0:
                    continue
                txt = (await loc.inner_text()).strip()
            except Exception as exc:  # noqa: BLE001
                raise SelectorError(f"{selector}: {_safe_exc(exc)}") from exc
            handle = _username_from_text(txt)
            if handle:
                return handle
        return None

    async def _scoped_money(self, root, label_selectors, value_selectors) -> tuple[bool, str | None]:
        """Return (label_present, raw_value) searching ONLY inside ``root`` (row/panel), §6."""
        if root is None:
            return (False, None)
        label = await find_first_visible(root, label_selectors, timeout_ms=800)
        if label is None:
            return (False, None)
        value = await self._first_matching_text(root, value_selectors, _looks_like_money)
        return (True, value)

    async def _scoped_items(self, root) -> int | None:
        if root is None:
            return None
        label = await find_first_visible(root, selectors.ITEMS_SOLD_LABELS, timeout_ms=500)
        if label is None:
            return None
        text = await self._first_matching_text(root, selectors.ITEMS_SOLD_VALUES, _looks_like_count)
        return _parse_count(text) if text else None

    async def _first_matching_text(self, root, value_selectors, predicate) -> str | None:
        for selector in value_selectors:
            try:
                elements = await root.locator(selector).all()
            except Exception as exc:  # noqa: BLE001
                raise SelectorError(f"value {selector}: {_safe_exc(exc)}") from exc
            for el in elements:
                with contextlib.suppress(Exception):
                    if await el.is_visible():
                        txt = (await el.inner_text()).strip()
                        if txt and predicate(txt):
                            return txt
        return None

    async def _wait_detail_ready(self):
        """Poll (cancel-aware) up to 15s for a detail panel / GMV label to appear (§5)."""
        deadline = DETAIL_TIMEOUT_MS / 1000
        waited = 0.0
        while waited < deadline:
            self._check_cancel()  # a stop must work even while waiting on the detail panel (§6)
            panel = await find_first_visible(self._page, selectors.DETAIL_PANEL, timeout_ms=500)
            if panel is not None:
                return panel
            label = await find_first_visible(self._page, selectors.GMV_LABELS, timeout_ms=500)
            if label is not None:
                return self._page  # GMV rendered without a distinct panel — scope to the page
            await asyncio.sleep(0.2)
            waited += 0.9
        raise CreatorDetailTimeoutError("detail panel/GMV label not shown within 15s")

    async def close(self) -> None:
        with contextlib.suppress(Exception):
            if self._context is not None:
                await self._context.close()
        with contextlib.suppress(Exception):
            if self._pw is not None:
                await self._pw.stop()
