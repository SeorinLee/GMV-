# GMV Worker

Python worker that does the real work: Excel parsing, GMV lookup automation (Playwright,
US Chrome / UK Edge) and format-preserving Excel output. Runs on a host with **Google
Chrome** and **Microsoft Edge** installed (never on Vercel — spec §8).

## Modules (`src/gmv/`)

| Module | Responsibility | Spec |
|---|---|---|
| `gmv_parser.py` | Raw GMV string → `ParsedGmv` (Decimal, range-max, open-ended) | §4, §5 |
| `creator.py` | Username normalize (`@`/URL/case) + exact matching | §2, §16 |
| `excel_engine.py` | Column detect, dedupe, openpyxl format-preserving write | §2, §3, §15 |
| `config.py` | US_CHROME / UK_EDGE profiles, row-level account resolution | §6, §7, §10 |
| `automation/` | Selector fallbacks, DOM+network extractors, session driver | §11, §16 |
| `job_runner.py` | Dedupe, per-account split, concurrency, retry orchestration | §10, §11, §15 |
| `service.py` | Job ↔ store bridge, per-row records, retry merge | §13, §15 |
| `store.py` | Local-fs job persistence (restart recovery) | §13, §14, §17 |
| `login_manager.py` | Manual (headed) login, verify, reset — no stored credentials | §9 |
| `api.py` / `worker_main.py` | FastAPI app + uvicorn entrypoint | §1, §9, §13 |

## Setup

```powershell
cd worker
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m playwright install chrome msedge   # uses installed channels
```

## Run

```powershell
$env:GMV_STORAGE_ROOT = "storage/jobs"
.\.venv\Scripts\python.exe -m gmv.worker_main         # http://127.0.0.1:8000
```

Log in first (opens a real browser you control):

```
POST /profiles/US_CHROME/login      # then log into TikTok Shop in the opened Chrome
POST /profiles/UK_EDGE/login        # log in in the opened Edge
```

## Test / lint

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m ruff check src tests
```

## Key environment variables

| Var | Default | Purpose |
|---|---|---|
| `GMV_STORAGE_ROOT` | `storage/jobs` | job files + json |
| `GMV_PROFILE_ROOT` | `storage/profiles` | per-profile browser data dirs (isolated) |
| `GMV_US_AFFILIATE_URL` | affiliate-us…?shop_region=US | US Affiliate Center |
| `GMV_UK_AFFILIATE_URL` | affiliate.tiktok.com/platform/homepage?shop_region=GB | UK Affiliate Center |
| `GMV_HEADLESS` | `0` | `1` = headless job runs |

> Selectors in `automation/selectors.py` and the UK affiliate URL are **unverified** against
> the live DOM — confirm against a logged-in session before production (docs/decisions.md D10).
