# Architecture Decisions

This file records non-obvious decisions and the reasonable defaults chosen where the
spec left details open (per spec §20).

## Context

Greenfield rebuild of a manual TikTok Shop Affiliate GMV lookup workflow. The legacy
code (`OneDrive\Desktop\TikTok_GMV_Daily\fill_gmv_*.py`) is a set of single-file
pandas + Playwright scripts, US-only, with fixed `wait_for_timeout` calls and
formatting-destroying `df.to_excel`. It is used only as a reference for reusable logic
(session-expiry detection, login model, search interaction, DOM text heuristic).

## Repository layout

```
tiktok-gmv-automation/
  worker/            Python: GMV parser, creator matching, Excel engine,
                     Playwright automation (US Chrome / UK Edge), FastAPI worker
  apps/web/          Next.js website (upload, account select, progress, download)
  supabase/          Postgres schema + migrations (jobs, rows, files, profiles)
  docker/            Worker image (Chrome + Edge + Playwright)
  docs/              decisions, deployment
```

Rationale: Vercel cannot run Playwright/real browsers (spec §8), so browser
automation + Excel processing live in a **separate Python Worker**. Web app is thin;
Supabase is the shared source of truth for job state and files.

## Decisions

- **D1 — Decimal, not float** for all money math (spec §5). `float` in legacy caused
  precision drift; parser uses `decimal.Decimal` throughout.
- **D2 — Range → max value** (spec §4). `$1K-$5K` → `5000`, type `RANGE_MAX`. Raw
  string preserved in `GMV Raw`.
- **D3 — Open-ended → estimate, never EXACT** (spec §4). `$5K+` → `5000` with type
  `OPEN_ENDED_ESTIMATE`; the worker first tries to find an exact/finite value in
  detail UI, and only falls back to the threshold if none is found.
- **D4 — Username-verified matching** (spec §16). Never take `.first` search result;
  normalize both sides and require exact equality, else `CREATOR_MISMATCH`. Legacy's
  display-name match is abandoned.
- **D5 — Normalization keeps `.` and `_`** — real TikTok usernames contain them
  (`wendy.sepulveda79`, `ms.lovely.ivonne_s`). We strip only `@`, whitespace, URL
  prefix, and trailing slash, and lowercase.
- **D6 — openpyxl in-place write** (spec §3). Load original workbook, mutate cells,
  save as new file → preserves styles, formulas, merges, widths, filters, freeze.
  pandas is NOT used for output.
- **D7 — GMV column placement**: if a `GMV` column exists, write into it; else insert
  a new `GMV` column immediately to the right of the detected creator column.
- **D8 — Default concurrency = 1** per account (spec §11), configurable 1–3. US Chrome
  and UK Edge run as independent workers and may run in parallel.
- **D9 — Extraction priority**: NetworkResponseExtractor → DOMExtractor → error
  (spec §11). Network extraction only reads responses the normal page already
  receives; no auth bypass, no private-API guessing.
- **D10 — Selector fallback lists**: real Affiliate Center DOM is not verified from the
  dev environment; all locators are defined as ordered fallback lists in one module
  (`automation/selectors.py`) so they can be corrected in one place after a live check.
- **D11 — No credentials stored**: TikTok login is manual (user drives the browser);
  only the browser profile/session files are persisted on the Worker host, never in
  the DB and never in git (see `.gitignore`).
- **D12 — MVP web → worker directly**: for the first release the Next.js app calls the
  Worker's HTTP API for upload/status/download; the Worker persists job state to local
  disk (restart-recoverable). Supabase (schema in `supabase/`) is the durable/multi-user
  store and auth layer, mirrored from the Worker in a later phase. This lets the MVP run
  fully on one PC without a Supabase project.
- **D13 — New result columns appended, not inserted**: openpyxl `insert_cols` does not
  reliably preserve styles/merges, so result columns are appended at the right edge to
  guarantee §3 format preservation. Existing `GMV` columns are written in place.

## UNVERIFIED (cannot be confirmed from the dev environment)

- Real Affiliate Center DOM structure / network response shapes (D10). Selectors are
  best-effort + fallbacks and MUST be validated against a logged-in session.
- Live GMV values, login, CAPTCHA/2FA (require the real account; manual by design).
- Supabase/Vercel deployment (require the user's projects + keys).
