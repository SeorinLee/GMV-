# Worker image with REAL Chrome + Edge channels (spec §8).
# Base = Playwright's Python image (browser OS deps preinstalled). We then install the
# Google Chrome Stable and Microsoft Edge Stable *channels* so US uses Chrome and UK uses
# Edge for real (spec §6) — not just bundled Chromium.
#
# NOTE: manual TikTok login (spec §9) needs a visible browser. In headless Linux you must
# either (a) pre-seed each profile via VNC/xvfb once, or (b) run the Worker on a Windows/VM
# host with a desktop (recommended — see docs/deployment.md). Job *runs* work headless
# (GMV_HEADLESS=1) once a profile is logged in.

FROM mcr.microsoft.com/playwright/python:v1.48.0-jammy

WORKDIR /app

COPY worker/pyproject.toml ./worker/pyproject.toml
COPY worker/src ./worker/src
RUN pip install --no-cache-dir ./worker

# Install the real stable channels used by the two markets.
RUN python -m playwright install chrome msedge && python -m playwright install-deps

ENV GMV_HOST=0.0.0.0 \
    GMV_PORT=8000 \
    GMV_STORAGE_ROOT=/data/jobs \
    GMV_PROFILE_ROOT=/data/profiles \
    GMV_HEADLESS=1

# Persist job files + logged-in browser profiles across restarts (spec §17).
VOLUME ["/data"]
EXPOSE 8000

CMD ["python", "-m", "gmv.worker_main"]
